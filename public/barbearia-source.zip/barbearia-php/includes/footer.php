<?php
$settings = $settings ?? getSettings();
$businessName = $settings['business_name'] ?? 'Barbearia';
$phone = $settings['whatsapp_number'] ?? '';
$schedule = '';
if (!empty($settings['opening_time']) && !empty($settings['closing_time'])) {
    $schedule = $settings['opening_time'] . ' - ' . $settings['closing_time'];
}
?>
<footer class="footer">
  <div class="footer-inner">
    <div class="logo" style="justify-content:center;margin-bottom:1rem">
      <div class="logo-icon gold-gradient" style="width:2.25rem;height:2.25rem;font-size:1rem">✂️</div>
      <span style="font-size:1.125rem;font-weight:700"><?= htmlspecialchars($businessName) ?></span>
    </div>
    <div style="display:flex;justify-content:center;gap:0.75rem;flex-wrap:wrap;margin-bottom:1.5rem">
      <?php if ($phone): ?>
        <span class="glass-card" style="padding:0.375rem 0.75rem;font-size:0.75rem;color:var(--muted);border-radius:0.5rem">📞 <?= htmlspecialchars($phone) ?></span>
      <?php endif; ?>
      <?php if ($schedule): ?>
        <span class="glass-card" style="padding:0.375rem 0.75rem;font-size:0.75rem;color:var(--muted);border-radius:0.5rem">🕐 <?= $schedule ?></span>
      <?php endif; ?>
    </div>
    <div style="width:3rem;height:1px;background:var(--glass-border);margin:0 auto 1rem"></div>
    <p style="font-size:0.6875rem;color:hsl(0 0% 30%)">© <?= date('Y') ?> <?= htmlspecialchars($businessName) ?>. Todos os direitos reservados.</p>
  </div>
</footer>
</body>
</html>
