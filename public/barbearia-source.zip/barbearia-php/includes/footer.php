<footer class="site-footer">
  <div class="container">
    <div class="footer-brand">
      <div class="header-logo" style="width:2.25rem;height:2.25rem;font-size:1rem;">✂</div>
      <span style="font-size:1.125rem;font-weight:700;"><?= htmlspecialchars($businessName ?? 'Barbearia') ?></span>
    </div>
    <p class="footer-copy">© <?= date('Y') ?> <?= htmlspecialchars($businessName ?? 'Barbearia') ?>. Todos os direitos reservados.</p>
  </div>
</footer>
</body>
</html>