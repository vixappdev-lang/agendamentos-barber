<?php
require_once __DIR__ . '/../config.php';
$settings = getSettings();
$businessName = $settings['business_name'] ?? 'Barbearia';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($businessName) ?></title>
  <meta name="description" content="<?= htmlspecialchars($businessName) ?> - Agendamento online, serviços premium de barbearia">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="header">
  <div class="header-inner">
    <a href="index.php" class="logo">
      <div class="logo-icon gold-gradient">✂️</div>
      <div>
        <h1 style="font-size:1.125rem;font-weight:700;line-height:1.2"><?= htmlspecialchars($businessName) ?></h1>
        <p style="font-size:0.625rem;color:var(--muted);text-transform:uppercase;letter-spacing:0.2em;margin-top:-2px">Premium Grooming</p>
      </div>
    </a>
    <a href="agendar.php" class="btn-primary" style="padding:0.5rem 1rem;font-size:0.75rem">Agendar</a>
  </div>
</header>
