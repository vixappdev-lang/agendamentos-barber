    </main>
  </div>
</div>
<script>
// Simple modal handling
function openModal(id) { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
</script>
</body>
</html>