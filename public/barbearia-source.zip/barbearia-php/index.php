<?php
require_once 'config.php';
$settings = getSettings();
$businessName = $settings['business_name'] ?? 'Barbearia';

$services = supabaseRequest('services?active=eq.true&order=sort_order.asc');
$products = supabaseRequest('products?active=eq.true&order=sort_order.asc');
$storeEnabled = ($settings['store_enabled'] ?? '') === 'true';

$category = $_GET['cat'] ?? 'all';
$tab = $_GET['tab'] ?? 'services';

setlocale(LC_TIME, 'pt_BR.UTF-8', 'pt_BR', 'portuguese');
$weekday = ucfirst(strftime('%A') ?: date('l'));
$day = date('j');
$month = strftime('%B') ?: date('F');

require 'includes/header.php';
?>

<main class="container">
  <!-- Greeting -->
  <div class="mb-6">
    <h2 style="font-size:1.75rem;font-weight:800;line-height:1.2">Olá, seja bem vindo!</h2>
    <p class="text-muted" style="margin-top:0.25rem"><?= $weekday ?>, <?= $day ?> de <?= $month ?></p>
  </div>

  <!-- Tabs (if store enabled) -->
  <?php if ($storeEnabled): ?>
  <div class="tab-bar">
    <a href="?tab=services" class="tab-btn <?= $tab === 'services' ? 'active' : '' ?>">✂️ Agendar</a>
    <a href="?tab=store" class="tab-btn <?= $tab === 'store' ? 'active' : '' ?>">🛍️ Loja</a>
  </div>
  <?php endif; ?>

  <!-- Search -->
  <div class="mb-6">
    <input type="text" class="glass-input" placeholder="Faça a sua busca..." id="searchInput" oninput="filterItems()" style="padding-left:2.5rem">
  </div>

  <?php if ($tab === 'services'): ?>
    <!-- Categories -->
    <div class="categories mb-6">
      <?php
      $cats = [
        ['all', 'Todos', '✨'], ['cabelo', 'Cabelo', '✂️'],
        ['barba', 'Barba', '🪒'], ['combo', 'Combos', '👑'], ['extras', 'Extras', '💎'],
      ];
      foreach ($cats as $c): ?>
        <a href="?cat=<?= $c[0] ?>" class="cat-btn <?= $category === $c[0] ? 'active' : '' ?>"><?= $c[1] ?> <?= $c[2] ?></a>
      <?php endforeach; ?>
    </div>

    <!-- Section label -->
    <div class="mb-4" style="display:flex;align-items:center;gap:0.5rem">
      <span style="color:var(--accent-light)">✂️</span>
      <h3 style="font-size:0.625rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:0.2em">Faça sua reserva</h3>
    </div>

    <!-- Service list -->
    <div style="display:flex;flex-direction:column;gap:1rem" id="serviceList">
      <?php if (is_array($services)): foreach ($services as $svc):
        $title = htmlspecialchars($svc['title']);
        $subtitle = htmlspecialchars($svc['subtitle'] ?? '');
        $price = number_format($svc['price'], 0, ',', '.');
        $duration = htmlspecialchars($svc['duration']);
        $imgUrl = $svc['image_url'] ?? '';
        if (strpos($imgUrl, 'stock://') === 0) $imgUrl = '';
        if (!$imgUrl) $imgUrl = 'https://images.unsplash.com/photo-1585747860019-8e4c78d7c4a7?w=600&h=400&fit=crop';

        // Category guess
        $lower = strtolower($svc['title']);
        $gcat = 'extras';
        if (strpos($lower, 'combo') !== false || strpos($lower, 'noivo') !== false || (strpos($lower, 'corte') !== false && strpos($lower, 'barba') !== false)) $gcat = 'combo';
        elseif (strpos($lower, 'barba') !== false) $gcat = 'barba';
        elseif (strpos($lower, 'corte') !== false || strpos($lower, 'cabelo') !== false || strpos($lower, 'degrad') !== false) $gcat = 'cabelo';

        if ($category !== 'all' && $gcat !== $category) continue;
      ?>
        <a href="agendar.php?service_id=<?= $svc['id'] ?>" class="glass-card service-card" data-title="<?= $title ?>" data-subtitle="<?= $subtitle ?>" style="text-decoration:none;display:block">
          <div style="position:relative;overflow:hidden">
            <img src="<?= $imgUrl ?>" alt="<?= $title ?>" class="service-img" loading="lazy">
            <div style="position:absolute;inset:0;background:linear-gradient(to top,hsl(230 20% 7%/0.7),transparent)"></div>
            <span style="position:absolute;top:0.75rem;right:0.75rem;display:flex;align-items:center;gap:0.25rem;padding:0.25rem 0.625rem;border-radius:0.5rem;font-size:0.75rem;font-weight:700;background:hsl(0 0% 0%/0.6);backdrop-filter:blur(8px);color:hsl(0 0% 90%)">🕐 <?= $duration ?></span>
          </div>
          <div class="service-body">
            <h3 style="font-size:1rem;font-weight:700"><?= $title ?></h3>
            <p style="font-size:0.8rem;color:var(--muted);margin-top:0.125rem"><?= $subtitle ?></p>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:0.75rem;padding-top:0.75rem;border-top:1px solid var(--glass-border)">
              <span class="gold-text" style="font-size:1.25rem;font-weight:700">R$ <?= $price ?></span>
              <span style="display:flex;align-items:center;gap:0.375rem;padding:0.5rem 1rem;border-radius:0.75rem;font-size:0.75rem;font-weight:600;text-transform:uppercase;letter-spacing:0.1em;background:hsl(0 0% 12%);color:hsl(0 0% 65%);border:1px solid hsl(0 0% 18%)">Agendar Aqui →</span>
            </div>
          </div>
        </a>
      <?php endforeach; endif; ?>
    </div>

  <?php else: ?>
    <!-- Store products -->
    <div class="mb-4" style="display:flex;align-items:center;gap:0.5rem">
      <span style="color:var(--accent-light)">🛍️</span>
      <h3 style="font-size:0.625rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:0.2em">Nossos Produtos</h3>
    </div>

    <div style="display:flex;flex-direction:column;gap:1rem" id="productList">
      <?php if (is_array($products)): foreach ($products as $prod):
        $title = htmlspecialchars($prod['title']);
        $desc = htmlspecialchars($prod['description'] ?? '');
        $price = number_format($prod['price'], 2, ',', '.');
        $imgUrl = $prod['image_url'] ?? 'https://images.unsplash.com/photo-1585747860019-8e4c78d7c4a7?w=400&h=300&fit=crop';
      ?>
        <div class="glass-card" style="padding:1rem;display:flex;align-items:center;gap:1rem" data-title="<?= $title ?>" data-subtitle="<?= $desc ?>">
          <img src="<?= $imgUrl ?>" alt="<?= $title ?>" style="width:4rem;height:4rem;border-radius:0.75rem;object-fit:cover;flex-shrink:0" loading="lazy">
          <div style="flex:1;min-width:0">
            <h4 style="font-size:0.875rem;font-weight:600"><?= $title ?></h4>
            <p style="font-size:0.75rem;color:var(--muted)"><?= $desc ?></p>
            <span style="font-size:0.875rem;font-weight:700;color:var(--accent-light);margin-top:0.25rem;display:block">R$ <?= $price ?></span>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  <?php endif; ?>
</main>

<script>
function filterItems() {
  const q = document.getElementById('searchInput').value.toLowerCase();
  document.querySelectorAll('[data-title]').forEach(el => {
    const t = (el.dataset.title + ' ' + el.dataset.subtitle).toLowerCase();
    el.style.display = t.includes(q) ? '' : 'none';
  });
}
</script>

<?php require 'includes/footer.php'; ?>
