<?php
require_once 'config.php';
$settings = getSettings();

$serviceId = $_GET['service_id'] ?? '';
$service = null;
if ($serviceId) {
    $res = supabaseRequest('services?id=eq.' . urlencode($serviceId) . '&limit=1');
    if (is_array($res) && count($res) > 0) $service = $res[0];
}
if (!$service) { header('Location: index.php'); exit; }

$barbers = supabaseRequest('barbers?active=eq.true&order=sort_order.asc') ?: [];

$openTime = $settings['opening_time'] ?? '09:00';
$closeTime = $settings['closing_time'] ?? '19:00';
$lunchStart = $settings['lunch_start'] ?? '12:00';
$lunchEnd = $settings['lunch_end'] ?? '13:00';
$daysOff = array_filter(explode(',', $settings['days_off'] ?? '0'));

// Generate available times
$times = [];
$h = intval(substr($openTime, 0, 2)); $m = intval(substr($openTime, 3, 2));
$ch = intval(substr($closeTime, 0, 2)); $cm = intval(substr($closeTime, 3, 2));
$lsh = intval(substr($lunchStart, 0, 2)); $lsm = intval(substr($lunchStart, 3, 2));
$leh = intval(substr($lunchEnd, 0, 2)); $lem = intval(substr($lunchEnd, 3, 2));
while ($h < $ch || ($h === $ch && $m < $cm)) {
    $t = sprintf('%02d:%02d', $h, $m);
    $inLunch = ($h > $lsh || ($h === $lsh && $m >= $lsm)) && ($h < $leh || ($h === $leh && $m < $lem));
    if (!$inLunch) $times[] = $t;
    $m += 30;
    if ($m >= 60) { $h++; $m = 0; }
}

// Generate dates (next 14 working days)
$dates = [];
$today = new DateTime();
for ($i = 1; $i <= 30 && count($dates) < 14; $i++) {
    $d = clone $today;
    $d->modify("+$i days");
    $dow = (int)$d->format('w');
    if (!in_array((string)$dow, $daysOff)) {
        $dates[] = ['value' => $d->format('Y-m-d'), 'weekday' => substr(['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][$dow], 0, 3), 'display' => $d->format('d/m')];
    }
}

$imgUrl = $service['image_url'] ?? '';
if (strpos($imgUrl, 'stock://') === 0) $imgUrl = '';
if (!$imgUrl) $imgUrl = 'https://images.unsplash.com/photo-1585747860019-8e4c78d7c4a7?w=600&h=400&fit=crop';

// Handle form submission
$success = false;
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $barber = $_POST['barber'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';

    if (!$name || !$phone || !$date || !$time) {
        $error = 'Preencha todos os campos obrigatórios.';
    } else {
        $result = supabaseRequest('appointments', 'POST', [
            'service_id' => $service['id'],
            'customer_name' => $name,
            'customer_phone' => $phone,
            'barber_name' => $barber ?: null,
            'appointment_date' => $date,
            'appointment_time' => $time,
            'total_price' => $service['price'],
            'status' => 'pending',
        ]);
        if (is_array($result) && isset($result[0]['id'])) {
            $success = true;
            $whatsapp = $settings['whatsapp_number'] ?? '5511999999999';
            $dateF = date('d/m/Y', strtotime($date));
            $msg = urlencode("Olá! Gostaria de confirmar meu agendamento:\n\n📋 Serviço: {$service['title']}\n💈 Barbeiro: $barber\n📅 Data: $dateF\n🕐 Horário: $time\n👤 Nome: $name\n📱 Telefone: $phone\n💰 Valor: R$ {$service['price']}");
        } else {
            $error = 'Erro ao agendar. Tente novamente.';
        }
    }
}

require 'includes/header.php';
?>

<main class="container" style="max-width:32rem">
  <?php if ($success): ?>
    <div class="glass-card-strong p-5" style="text-align:center">
      <div style="font-size:3rem;margin-bottom:1rem">✅</div>
      <h2 style="font-size:1.25rem;font-weight:700;margin-bottom:0.5rem">Agendamento Realizado!</h2>
      <p class="text-sm text-muted" style="margin-bottom:1.5rem">Seu agendamento foi registrado com sucesso.</p>
      <div style="display:flex;gap:0.75rem;flex-direction:column">
        <a href="https://wa.me/<?= $whatsapp ?>?text=<?= $msg ?>" target="_blank" class="btn-primary" style="background:hsl(142 70% 40%);width:100%">📱 Confirmar via WhatsApp</a>
        <a href="index.php" class="btn-secondary" style="width:100%">← Voltar ao Início</a>
      </div>
    </div>
  <?php else: ?>
    <a href="index.php" class="btn-secondary mb-6" style="display:inline-flex">← Voltar</a>

    <!-- Service info -->
    <div class="glass-card" style="display:flex;align-items:center;gap:1rem;padding:1rem;margin-bottom:1.5rem">
      <img src="<?= $imgUrl ?>" alt="<?= htmlspecialchars($service['title']) ?>" style="width:4rem;height:4rem;border-radius:0.75rem;object-fit:cover">
      <div>
        <h3 style="font-weight:700"><?= htmlspecialchars($service['title']) ?></h3>
        <p class="text-sm text-muted"><?= htmlspecialchars($service['subtitle'] ?? '') ?></p>
        <div style="display:flex;gap:1rem;align-items:center;margin-top:0.5rem">
          <span class="gold-text font-bold text-lg">R$ <?= number_format($service['price'], 0, ',', '.') ?></span>
          <span class="text-xs text-muted">🕐 <?= htmlspecialchars($service['duration']) ?></span>
        </div>
      </div>
    </div>

    <?php if ($error): ?>
      <div class="glass-card" style="padding:0.75rem 1rem;margin-bottom:1rem;border-color:hsl(0 60% 50% / 0.3)">
        <p style="font-size:0.875rem;color:hsl(0 60% 60%)">⚠️ <?= htmlspecialchars($error) ?></p>
      </div>
    <?php endif; ?>

    <form method="POST" class="glass-card-strong" style="padding:1.5rem">
      <h2 style="font-size:1.125rem;font-weight:700;margin-bottom:1.25rem">Agendamento</h2>

      <!-- Barber -->
      <div class="mb-4">
        <label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.5rem">💈 Barbeiro</label>
        <div style="display:flex;flex-direction:column;gap:0.5rem">
          <?php foreach ($barbers as $b): ?>
            <label class="glass-card" style="padding:0.75rem 1rem;display:flex;align-items:center;gap:0.75rem;cursor:pointer">
              <input type="radio" name="barber" value="<?= htmlspecialchars($b['name']) ?>" style="accent-color:var(--accent)">
              <div style="width:2.5rem;height:2.5rem;border-radius:0.75rem;display:flex;align-items:center;justify-content:center;font-weight:700;background:hsl(245 60% 55%/0.12);color:var(--accent-light)">
                <?= mb_substr($b['name'], 0, 1) ?>
              </div>
              <div>
                <span class="font-semibold text-sm"><?= htmlspecialchars($b['name']) ?></span>
                <span class="text-xs text-muted" style="display:block"><?= htmlspecialchars($b['specialty'] ?? 'Barbeiro') ?></span>
              </div>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Date -->
      <div class="mb-4">
        <label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.5rem">📅 Data</label>
        <div style="display:flex;gap:0.5rem;overflow-x:auto;padding-bottom:0.5rem" class="categories">
          <?php foreach ($dates as $d): ?>
            <label style="flex-shrink:0;width:4rem;text-align:center;padding:0.75rem 0;border-radius:0.75rem;cursor:pointer;border:1px solid var(--glass-border);background:var(--glass);transition:all 0.2s">
              <input type="radio" name="date" value="<?= $d['value'] ?>" style="display:none" onchange="this.closest('label').style.background='linear-gradient(135deg,hsl(245 60% 50%),hsl(265 60% 55%))';this.closest('label').style.color='white';this.closest('label').style.borderColor='transparent'">
              <span style="display:block;font-size:0.625rem;text-transform:uppercase;opacity:0.7"><?= $d['weekday'] ?></span>
              <span style="display:block;font-size:0.875rem;font-weight:700;margin-top:0.125rem"><?= $d['display'] ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Time -->
      <div class="mb-4">
        <label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.5rem">🕐 Horário</label>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0.5rem;max-height:10rem;overflow-y:auto">
          <?php foreach ($times as $t): ?>
            <label style="text-align:center;padding:0.625rem;border-radius:0.75rem;cursor:pointer;font-size:0.875rem;font-weight:500;background:var(--glass);border:1px solid var(--glass-border);color:hsl(0 0% 55%);transition:all 0.2s">
              <input type="radio" name="time" value="<?= $t ?>" style="display:none" onchange="this.closest('label').style.background='linear-gradient(135deg,hsl(245 60% 50%),hsl(265 60% 55%))';this.closest('label').style.color='white';this.closest('label').style.borderColor='transparent'">
              <?= $t ?>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Name & Phone -->
      <div class="mb-4">
        <label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.5rem">👤 Seu nome</label>
        <input type="text" name="name" class="glass-input" placeholder="Digite seu nome" required>
      </div>
      <div class="mb-6">
        <label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.5rem">📱 WhatsApp</label>
        <input type="tel" name="phone" class="glass-input" placeholder="(11) 99999-9999" required>
      </div>

      <button type="submit" class="btn-primary w-full">Confirmar Agendamento →</button>
    </form>
  <?php endif; ?>
</main>

<?php require 'includes/footer.php'; ?>
