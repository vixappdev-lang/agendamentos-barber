<?php
require_once __DIR__ . '/../config.php';
$token = $_SESSION['admin_token'] ?? '';
$tab = $_GET['tab'] ?? 'products';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save_product') {
        $payload = ['title' => $_POST['title'] ?? '', 'description' => $_POST['description'] ?: null, 'price' => (float)($_POST['price'] ?? 0), 'image_url' => $_POST['image_url'] ?: null, 'active' => isset($_POST['active']), 'sort_order' => (int)($_POST['sort_order'] ?? 0)];
        $id = $_POST['id'] ?? '';
        if ($id) supabase_request("products?id=eq.$id", 'PATCH', $payload, $token);
        else supabase_request('products', 'POST', $payload, $token);
        header('Location: store.php?tab=products'); exit;
    }
    if ($action === 'delete_product') { supabase_request("products?id=eq.{$_POST['id']}", 'DELETE', null, $token); header('Location: store.php?tab=products'); exit; }
    if ($action === 'update_order_status') {
        supabase_request("orders?id=eq.{$_POST['id']}", 'PATCH', ['status' => $_POST['status']], $token);
        header('Location: store.php?tab=orders&' . http_build_query(array_diff_key($_GET, ['tab'=>1]))); exit;
    }
    if ($action === 'delete_order') { supabase_request("orders?id=eq.{$_POST['id']}", 'DELETE', null, $token); header('Location: store.php?tab=orders'); exit; }
    if ($action === 'save_settings') {
        $keys = ['store_enabled', 'store_order_mode', 'pix_key', 'pix_type'];
        foreach ($keys as $key) {
            $value = $_POST[$key] ?? '';
            supabase_request("business_settings?key=eq.$key", 'PATCH', ['value' => $value], $token);
            $check = supabase_request("business_settings?key=eq.$key", 'GET', null, $token);
            if (empty($check['data'])) supabase_request('business_settings', 'POST', ['key' => $key, 'value' => $value], $token);
        }
        header('Location: store.php?tab=settings&saved=1'); exit;
    }
}

require 'includes/admin_header.php';
$settings = get_settings();
?>
<h2 style="font-size:1.125rem;font-weight:700;margin-bottom:1rem;">Loja</h2>

<div class="filter-bar" style="margin-bottom:1rem;">
  <a href="?tab=products" class="filter-btn <?= $tab === 'products' ? 'active' : '' ?>">🛍 Produtos</a>
  <a href="?tab=orders" class="filter-btn <?= $tab === 'orders' ? 'active' : '' ?>">📦 Pedidos</a>
  <a href="?tab=settings" class="filter-btn <?= $tab === 'settings' ? 'active' : '' ?>">⚙ Configurações</a>
</div>

<?php if ($tab === 'products'):
$products = (supabase_request('products?order=sort_order', 'GET', null, $token))['data'] ?? [];
?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
  <span style="font-size:0.875rem;font-weight:600;">Produtos / Loja</span>
  <button class="btn-accent" onclick="openModal('productModal')" style="font-size:0.75rem;">➕ Novo Produto</button>
</div>
<?php foreach ($products as $p): ?>
<div class="glass-card list-item">
  <?php if (!empty($p['image_url'])): ?><img src="<?= htmlspecialchars($p['image_url']) ?>" class="list-thumb"><?php else: ?><div class="list-thumb-placeholder">🛍</div><?php endif; ?>
  <div class="list-info">
    <div style="display:flex;align-items:center;gap:0.5rem;"><span class="list-title"><?= htmlspecialchars($p['title']) ?></span><?php if (!$p['active']): ?><span class="badge badge-inactive">Inativo</span><?php endif; ?></div>
    <div class="list-sub"><?= htmlspecialchars($p['description'] ?? '') ?></div>
    <span class="list-price">R$ <?= number_format($p['price'], 2, ',', '.') ?></span>
  </div>
  <div class="list-actions">
    <button class="btn-edit" onclick="editProduct(<?= htmlspecialchars(json_encode($p)) ?>)">✏</button>
    <form method="post" style="display:inline;" onsubmit="return confirm('Excluir?');"><input type="hidden" name="action" value="delete_product"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button type="submit" class="btn-delete">🗑</button></form>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($products)): ?><div class="glass-card" style="padding:2rem;text-align:center;"><p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum produto cadastrado</p></div><?php endif; ?>

<div class="modal-overlay" id="productModal" style="display:none;">
  <div class="glass-card-strong modal-content">
    <div class="modal-header"><h3 id="productModalTitle">Novo Produto</h3><button class="modal-close" onclick="closeModal('productModal')">✕</button></div>
    <form method="post">
      <input type="hidden" name="action" value="save_product"><input type="hidden" name="id" id="p_id">
      <div class="form-group"><label class="form-label">Nome *</label><input class="glass-input" name="title" id="p_title" required></div>
      <div class="form-group"><label class="form-label">Descrição</label><textarea class="glass-input" name="description" id="p_desc" style="min-height:5rem;resize:none;"></textarea></div>
      <div class="form-group"><label class="form-label">Preço (R$) *</label><input class="glass-input" name="price" id="p_price" type="number" step="0.01" min="0" required></div>
      <div class="form-group"><label class="form-label">URL da Imagem</label><input class="glass-input" name="image_url" id="p_image"></div>
      <input type="hidden" name="sort_order" id="p_order" value="0">
      <div class="form-group" style="display:flex;align-items:center;gap:0.75rem;"><label class="form-label" style="margin:0;">Ativo</label><input type="checkbox" name="active" id="p_active" checked></div>
      <button type="submit" class="btn-accent" style="width:100%;justify-content:center;">💾 Salvar</button>
    </form>
  </div>
</div>
<script>
function editProduct(p) {
  document.getElementById('productModalTitle').textContent = 'Editar Produto';
  document.getElementById('p_id').value = p.id;
  document.getElementById('p_title').value = p.title;
  document.getElementById('p_desc').value = p.description || '';
  document.getElementById('p_price').value = p.price;
  document.getElementById('p_image').value = p.image_url || '';
  document.getElementById('p_active').checked = p.active;
  document.getElementById('p_order').value = p.sort_order || 0;
  openModal('productModal');
}
</script>

<?php elseif ($tab === 'orders'):
$filterStatus = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;

$url = 'orders?order=created_at.desc';
if ($filterStatus !== 'all') $url .= "&status=eq.$filterStatus";
if ($search) $url .= "&or=(customer_name.ilike.*$search*,customer_phone.ilike.*$search*)";
$orders = (supabase_request($url, 'GET', null, $token))['data'] ?? [];
$totalOrders = count($orders);
$totalPages = max(1, ceil($totalOrders / $perPage));
$page = min($page, $totalPages);
$pagedOrders = array_slice($orders, ($page - 1) * $perPage, $perPage);

$statuses = [
  ['id' => 'pending', 'label' => 'Pendente', 'class' => 'status-pending'],
  ['id' => 'confirmed', 'label' => 'Confirmado', 'class' => 'status-confirmed'],
  ['id' => 'preparing', 'label' => 'Preparando', 'class' => 'status-preparing'],
  ['id' => 'delivering', 'label' => 'Saiu p/ entrega', 'class' => 'status-delivering'],
  ['id' => 'completed', 'label' => 'Concluído', 'class' => 'status-completed'],
  ['id' => 'cancelled', 'label' => 'Cancelado', 'class' => 'status-cancelled'],
];
$statusMap = array_column($statuses, null, 'id');
?>
<div style="display:flex;align-items:center;gap:0.5rem;margin-bottom:0.75rem;">
  <span style="font-size:0.875rem;font-weight:600;">📦 Pedidos</span>
  <span class="badge" style="background:hsl(245,60%,55%,0.1);color:hsl(245,60%,70%);"><?= $totalOrders ?></span>
</div>
<div style="display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:0.75rem;">
  <form method="get" style="flex:1;min-width:12rem;">
    <input type="hidden" name="tab" value="orders">
    <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>">
    <input class="glass-input" name="search" placeholder="Buscar..." value="<?= htmlspecialchars($search) ?>" style="font-size:0.8125rem;">
  </form>
</div>
<div class="filter-bar">
  <a href="?tab=orders&search=<?= urlencode($search) ?>" class="filter-btn <?= $filterStatus === 'all' ? 'active' : '' ?>">Todos</a>
  <?php foreach ($statuses as $s): ?>
    <a href="?tab=orders&status=<?= $s['id'] ?>&search=<?= urlencode($search) ?>" class="filter-btn <?= $filterStatus === $s['id'] ? 'active' : '' ?>"><?= $s['label'] ?></a>
  <?php endforeach; ?>
</div>

<?php foreach ($pagedOrders as $o): $st = $statusMap[$o['status']] ?? $statusMap['pending']; ?>
<div class="glass-card" style="padding:1rem;margin-bottom:0.5rem;display:flex;align-items:center;gap:0.75rem;">
  <div style="flex:1;min-width:0;">
    <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
      <span style="font-size:0.875rem;font-weight:600;"><?= htmlspecialchars($o['customer_name']) ?></span>
      <span class="badge <?= $st['class'] ?>"><?= $st['label'] ?></span>
    </div>
    <div style="display:flex;align-items:center;gap:0.75rem;margin-top:0.25rem;font-size:0.75rem;color:var(--muted-foreground);">
      <span><?= date('d/m/y H:i', strtotime($o['created_at'])) ?></span>
      <span style="font-weight:600;color:hsl(245,60%,70%);">R$ <?= number_format($o['total_price'], 2, ',', '.') ?></span>
      <span><?= $o['delivery_mode'] === 'delivery' ? '🚚 Entrega' : '🏪 Retirada' ?></span>
    </div>
  </div>
  <div style="display:flex;gap:0.25rem;">
    <form method="post" style="display:inline;">
      <input type="hidden" name="action" value="update_order_status">
      <input type="hidden" name="id" value="<?= $o['id'] ?>">
      <select name="status" class="glass-input" style="font-size:0.6875rem;padding:0.375rem 0.5rem;width:auto;" onchange="this.form.submit()">
        <?php foreach ($statuses as $s): ?>
          <option value="<?= $s['id'] ?>" <?= $o['status'] === $s['id'] ? 'selected' : '' ?>><?= $s['label'] ?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <form method="post" style="display:inline;" onsubmit="return confirm('Excluir?');"><input type="hidden" name="action" value="delete_order"><input type="hidden" name="id" value="<?= $o['id'] ?>"><button type="submit" class="btn-delete">🗑</button></form>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($pagedOrders)): ?><div class="glass-card" style="padding:2rem;text-align:center;"><p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum pedido encontrado</p></div><?php endif; ?>

<?php if ($totalPages > 1): ?>
<div class="pagination">
  <?php if ($page > 1): ?><a href="?tab=orders&page=<?= $page-1 ?>&status=<?= $filterStatus ?>&search=<?= urlencode($search) ?>" class="page-btn">◀</a><?php endif; ?>
  <?php for ($i = max(1, $page-2); $i <= min($totalPages, $page+2); $i++): ?>
    <a href="?tab=orders&page=<?= $i ?>&status=<?= $filterStatus ?>&search=<?= urlencode($search) ?>" class="page-btn <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
  <?php endfor; ?>
  <?php if ($page < $totalPages): ?><a href="?tab=orders&page=<?= $page+1 ?>&status=<?= $filterStatus ?>&search=<?= urlencode($search) ?>" class="page-btn">▶</a><?php endif; ?>
</div>
<?php endif; ?>

<?php elseif ($tab === 'settings'): $saved = isset($_GET['saved']); ?>
<?php if ($saved): ?>
<div class="glass-card" style="padding:0.75rem;margin-bottom:1rem;border-color:hsl(140,60%,50%,0.3);text-align:center;">
  <p style="font-size:0.875rem;color:hsl(140,60%,55%);">✅ Configurações da loja salvas!</p>
</div>
<?php endif; ?>
<form method="post">
  <input type="hidden" name="action" value="save_settings">
  <div class="glass-card" style="padding:1.25rem;margin-bottom:1rem;">
    <div style="display:flex;align-items:center;justify-content:space-between;">
      <div><h3 style="font-size:0.875rem;font-weight:600;">🛍 Loja / Marketplace</h3><p style="font-size:0.6875rem;color:var(--muted-foreground);">Ativar seção de produtos</p></div>
      <select name="store_enabled" class="glass-input" style="width:auto;font-size:0.75rem;padding:0.375rem 0.75rem;">
        <option value="true" <?= ($settings['store_enabled'] ?? '') === 'true' ? 'selected' : '' ?>>Ativada</option>
        <option value="false" <?= ($settings['store_enabled'] ?? '') !== 'true' ? 'selected' : '' ?>>Desativada</option>
      </select>
    </div>
  </div>
  <div class="glass-card" style="padding:1.25rem;margin-bottom:1rem;">
    <h3 style="font-size:0.875rem;font-weight:600;margin-bottom:1rem;">💳 Modo de Pedido & PIX</h3>
    <div class="form-group"><label class="form-label">Modo de Pedido</label>
      <div class="grid-2">
        <label class="filter-btn" style="cursor:pointer;text-align:center;<?= ($settings['store_order_mode'] ?? 'whatsapp') === 'ifood' ? 'background:hsl(245,60%,55%,0.15);color:hsl(245,60%,70%);border-color:hsl(245,60%,55%,0.3);' : '' ?>">
          <input type="radio" name="store_order_mode" value="ifood" <?= ($settings['store_order_mode'] ?? 'whatsapp') === 'ifood' ? 'checked' : '' ?> style="display:none;">🛒 Similar ao iFood
        </label>
        <label class="filter-btn" style="cursor:pointer;text-align:center;<?= ($settings['store_order_mode'] ?? 'whatsapp') === 'whatsapp' ? 'background:hsl(245,60%,55%,0.15);color:hsl(245,60%,70%);border-color:hsl(245,60%,55%,0.3);' : '' ?>">
          <input type="radio" name="store_order_mode" value="whatsapp" <?= ($settings['store_order_mode'] ?? 'whatsapp') === 'whatsapp' ? 'checked' : '' ?> style="display:none;">📱 Via WhatsApp
        </label>
      </div>
    </div>
    <div class="grid-2">
      <div class="form-group"><label class="form-label">Tipo Chave PIX</label>
        <select class="glass-input" name="pix_type">
          <?php foreach (['cpf'=>'CPF','cnpj'=>'CNPJ','email'=>'Email','telefone'=>'Telefone','aleatoria'=>'Chave Aleatória'] as $v => $l): ?>
            <option value="<?= $v ?>" <?= ($settings['pix_type'] ?? 'cpf') === $v ? 'selected' : '' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Chave PIX</label><input class="glass-input" name="pix_key" value="<?= htmlspecialchars($settings['pix_key'] ?? '') ?>" placeholder="Sua chave PIX"></div>
    </div>
  </div>
  <button type="submit" class="btn-accent" style="width:100%;justify-content:center;padding:0.875rem;">💾 Salvar Configurações</button>
</form>
<?php endif; ?>
<?php require 'includes/admin_footer.php'; ?>