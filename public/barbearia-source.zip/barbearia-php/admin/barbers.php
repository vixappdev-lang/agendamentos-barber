<?php
require_once __DIR__ . '/../config.php';
require_admin();
$token = $_SESSION['admin_token'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $payload = ['name' => $_POST['name'] ?? '', 'specialty' => $_POST['specialty'] ?: null, 'avatar_url' => $_POST['avatar_url'] ?: null, 'active' => isset($_POST['active']), 'sort_order' => (int)($_POST['sort_order'] ?? 0)];
        $id = $_POST['id'] ?? '';
        if ($id) supabase_request("barbers?id=eq.$id", 'PATCH', $payload, $token);
        else supabase_request('barbers', 'POST', $payload, $token);
        header('Location: barbers.php'); exit;
    }
    if ($action === 'delete') { supabase_request("barbers?id=eq.{$_POST['id']}", 'DELETE', null, $token); header('Location: barbers.php'); exit; }
}
$barbers = (supabase_request('barbers?order=sort_order', 'GET', null, $token))['data'] ?? [];
require_once __DIR__ . '/../includes/admin_header.php';
?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
  <h2 style="font-size:1.125rem;font-weight:700;">Barbeiros</h2>
  <button class="btn-accent" onclick="openModal('barberModal')" style="font-size:0.75rem;">➕ Novo Barbeiro</button>
</div>
<?php foreach ($barbers as $b): ?>
<div class="glass-card list-item">
  <?php if (!empty($b['avatar_url'])): ?>
    <img src="<?= htmlspecialchars($b['avatar_url']) ?>" class="list-thumb">
  <?php else: ?>
    <div class="list-thumb-placeholder" style="background:hsl(245,60%,55%,0.12);color:hsl(245,60%,65%);font-weight:700;font-size:1.125rem;"><?= mb_substr($b['name'],0,1) ?></div>
  <?php endif; ?>
  <div class="list-info">
    <div style="display:flex;align-items:center;gap:0.5rem;">
      <span class="list-title"><?= htmlspecialchars($b['name']) ?></span>
      <?php if (!$b['active']): ?><span class="badge badge-inactive">Inativo</span><?php endif; ?>
    </div>
    <div class="list-sub"><?= htmlspecialchars($b['specialty'] ?? 'Sem especialidade') ?></div>
  </div>
  <div class="list-actions">
    <button class="btn-edit" onclick="editBarber(<?= htmlspecialchars(json_encode($b)) ?>)">✏</button>
    <form method="post" style="display:inline;" onsubmit="return confirm('Excluir?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $b['id'] ?>"><button type="submit" class="btn-delete">🗑</button></form>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($barbers)): ?><div class="glass-card" style="padding:2rem;text-align:center;"><p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum barbeiro cadastrado</p></div><?php endif; ?>

<div class="modal-overlay" id="barberModal" style="display:none;">
  <div class="glass-card-strong modal-content">
    <div class="modal-header"><h3 id="barberModalTitle">Novo Barbeiro</h3><button class="modal-close" onclick="closeModal('barberModal')">✕</button></div>
    <form method="post">
      <input type="hidden" name="action" value="save"><input type="hidden" name="id" id="b_id">
      <div class="form-group"><label class="form-label">Nome *</label><input class="glass-input" name="name" id="b_name" required></div>
      <div class="form-group"><label class="form-label">Especialidade</label><input class="glass-input" name="specialty" id="b_spec"></div>
      <div class="form-group"><label class="form-label">URL Foto</label><input class="glass-input" name="avatar_url" id="b_avatar"></div>
      <div class="form-group" style="display:flex;align-items:center;gap:0.75rem;"><label class="form-label" style="margin:0;">Ativo</label><input type="checkbox" name="active" id="b_active" checked></div>
      <input type="hidden" name="sort_order" id="b_order" value="0">
      <button type="submit" class="btn-accent" style="width:100%;justify-content:center;">💾 Salvar</button>
    </form>
  </div>
</div>
<script>
function editBarber(b) {
  document.getElementById('barberModalTitle').textContent = 'Editar Barbeiro';
  document.getElementById('b_id').value = b.id;
  document.getElementById('b_name').value = b.name;
  document.getElementById('b_spec').value = b.specialty || '';
  document.getElementById('b_avatar').value = b.avatar_url || '';
  document.getElementById('b_active').checked = b.active;
  document.getElementById('b_order').value = b.sort_order || 0;
  openModal('barberModal');
}
</script>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>