<?php
require_once __DIR__ . '/../config.php';
if (!isAdmin()) { header('Location: login.php'); exit; }
$token = getAdminToken();

$appointments = supabaseRequest('appointments?select=*', 'GET', null, $token) ?: [];
$services = supabaseRequest('services?select=*', 'GET', null, $token) ?: [];

$today = date('Y-m-d');
$todayApps = array_filter($appointments, fn($a) => $a['appointment_date'] === $today);
$totalRevenue = array_sum(array_map(fn($a) => floatval($a['total_price'] ?? 0), $appointments));
$activeServices = count(array_filter($services, fn($s) => $s['active']));

$page = $_GET['page'] ?? 'dashboard';
require 'layout.php';
?>
