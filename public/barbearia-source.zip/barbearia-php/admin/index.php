<?php
require_once __DIR__ . '/../config.php';
require_admin();
$token = $_SESSION['admin_token'] ?? '';
$appointmentsRes = supabase_request('appointments?select=*', 'GET', null, $token);
$servicesRes = supabase_request('services?select=*', 'GET', null, $token);
$appointments = $appointmentsRes['data'] ?? [];
$services = $servicesRes['data'] ?? [];
$today = date('Y-m-d');
$todayApps = array_filter($appointments, fn($a) => $a['appointment_date'] === $today);
$totalRevenue = array_sum(array_map(fn($a) => (float)($a['total_price'] ?? 0), $appointments));
$activeServices = count(array_filter($services, fn($s) => $s['active'] ?? false));
require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="stat-grid">
  <div class="glass-card stat-card">
    <div class="stat-icon" style="background:hsl(245,60%,55%,0.12);color:hsl(245,60%,55%);">📅</div>
    <div class="stat-value"><?= count($todayApps) ?></div>
    <div class="stat-label">Agendamentos Hoje</div>
  </div>
  <div class="glass-card stat-card">
    <div class="stat-icon" style="background:hsl(200,70%,50%,0.12);color:hsl(200,70%,50%);">👤</div>
    <div class="stat-value"><?= count($appointments) ?></div>
    <div class="stat-label">Total Agendamentos</div>
  </div>
  <div class="glass-card stat-card">
    <div class="stat-icon" style="background:hsl(160,60%,45%,0.12);color:hsl(160,60%,45%);">💰</div>
    <div class="stat-value">R$ <?= number_format($totalRevenue, 2, ',', '.') ?></div>
    <div class="stat-label">Receita Total</div>
  </div>
  <div class="glass-card stat-card">
    <div class="stat-icon" style="background:hsl(280,60%,55%,0.12);color:hsl(280,60%,55%);">✂</div>
    <div class="stat-value"><?= $activeServices ?></div>
    <div class="stat-label">Serviços Ativos</div>
  </div>
</div>

<div class="glass-card" style="padding:1.25rem;">
  <h3 style="font-size:0.875rem;font-weight:600;margin-bottom:1rem;">Distribuição por Serviço</h3>
  <?php
  $dist = [];
  foreach ($appointments as $app) {
    $svc = null;
    foreach ($services as $s) { if ($s['id'] === ($app['service_id'] ?? '')) { $svc = $s; break; } }
    $name = $svc['title'] ?? 'Outro';
    $dist[$name] = ($dist[$name] ?? 0) + 1;
  }
  arsort($dist);
  $total = array_sum($dist);
  $colors = ['hsl(245,60%,55%)', 'hsl(200,70%,50%)', 'hsl(160,60%,45%)', 'hsl(280,60%,55%)', 'hsl(30,70%,50%)', 'hsl(350,60%,50%)'];
  $i = 0;
  if (empty($dist)): ?>
    <p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum agendamento registrado ainda</p>
  <?php else: ?>
    <?php foreach ($dist as $name => $count): $pct = $total > 0 ? round($count / $total * 100) : 0; $color = $colors[$i % count($colors)]; ?>
      <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:0.5rem;">
        <div style="width:0.625rem;height:0.625rem;border-radius:50%;flex-shrink:0;background:<?= $color ?>;"></div>
        <span style="font-size:0.875rem;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($name) ?></span>
        <span style="font-size:0.75rem;color:var(--muted-foreground);"><?= $count ?> (<?= $pct ?>%)</span>
        <div style="width:6rem;height:0.375rem;border-radius:9999px;overflow:hidden;background:hsl(0,0%,100%,0.06);">
          <div style="height:100%;width:<?= $pct ?>%;border-radius:9999px;background:<?= $color ?>;"></div>
        </div>
      </div>
    <?php $i++; endforeach; ?>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>