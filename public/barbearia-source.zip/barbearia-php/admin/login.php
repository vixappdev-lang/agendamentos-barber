<?php
require_once __DIR__ . '/../config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $authResult = supabase_auth('token?grant_type=password', ['email' => $email, 'password' => $password]);
    if (isset($authResult['access_token'])) {
        $token = $authResult['access_token'];
        $userId = $authResult['user']['id'] ?? '';
        $rolesResult = supabase_request("user_roles?user_id=eq.$userId&role=eq.admin", 'GET', null, $token);
        if (!empty($rolesResult['data'])) {
            $_SESSION['admin_token'] = $token;
            $_SESSION['admin_user_id'] = $userId;
            header('Location: index.php');
            exit;
        } else {
            $error = 'Acesso negado. Você não é administrador.';
        }
    } else {
        $error = 'Credenciais inválidas.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="login-wrap">
  <div class="glass-card-strong login-card">
    <div class="login-header">
      <div class="login-logo">✂</div>
      <div style="font-size:0.625rem;font-weight:600;letter-spacing:0.2em;text-transform:uppercase;color:hsl(245,60%,70%);margin-bottom:1rem;">PAINEL ADMIN</div>
      <h2 class="login-title">Acesse sua conta</h2>
      <p class="login-sub">Bem-vindo de volta. Digite seus dados para entrar.</p>
    </div>
    <?php if ($error): ?>
      <div class="glass-card" style="padding:0.75rem;margin-bottom:1rem;border-color:hsl(0,60%,50%,0.3);text-align:center;">
        <p style="font-size:0.875rem;color:hsl(0,60%,60%);"><?= htmlspecialchars($error) ?></p>
      </div>
    <?php endif; ?>
    <form method="post">
      <div class="form-group">
        <label class="form-label">E-mail</label>
        <input type="email" name="email" class="glass-input" placeholder="seu@email.com" required>
      </div>
      <div class="form-group">
        <label class="form-label">Senha</label>
        <input type="password" name="password" class="glass-input" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn-accent" style="width:100%;justify-content:center;padding:0.875rem;background:linear-gradient(135deg,hsl(245,60%,50%),hsl(265,60%,55%));font-weight:600;">
        ENTRAR →
      </button>
    </form>
    <p style="text-align:center;font-size:0.75rem;color:var(--muted-foreground);margin-top:1.5rem;">Dificuldades no acesso? Contatar o suporte</p>
  </div>
</div>
</body>
</html>