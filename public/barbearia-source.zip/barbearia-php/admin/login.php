<?php
require_once __DIR__ . '/../config.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $auth = supabaseAuth('token?grant_type=password', [
        'email' => $email,
        'password' => $password,
    ]);

    if (isset($auth['access_token'])) {
        $userId = $auth['user']['id'];
        $roles = supabaseRequest('user_roles?user_id=eq.' . $userId . '&role=eq.admin&select=role', 'GET', null, $auth['access_token']);

        if (is_array($roles) && count($roles) > 0) {
            $_SESSION['admin_token'] = $auth['access_token'];
            $_SESSION['admin_user'] = $auth['user'];
            header('Location: index.php');
            exit;
        } else {
            $error = 'Acesso negado. Você não é administrador.';
        }
    } else {
        $error = 'Credenciais inválidas.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem">
  <div class="glass-card-strong" style="width:100%;max-width:24rem;padding:2rem">
    <div style="display:flex;align-items:center;gap:0.5rem;margin-bottom:2rem">
      <div style="width:2.5rem;height:2.5rem;border-radius:0.75rem;display:flex;align-items:center;justify-content:center;background:hsl(245 60% 55% / 0.15);border:1px solid hsl(245 60% 55% / 0.3);font-size:1.25rem">✂️</div>
      <span style="font-size:0.75rem;font-weight:600;letter-spacing:0.2em;text-transform:uppercase;color:var(--accent-light)">PAINEL ADMIN</span>
    </div>

    <h2 style="font-size:1.5rem;font-weight:700;margin-bottom:0.25rem">Acesse sua conta</h2>
    <p class="text-sm text-muted" style="margin-bottom:2rem">Bem-vindo de volta. Digite seus dados para entrar.</p>

    <?php if ($error): ?>
      <div style="padding:0.75rem;border-radius:0.75rem;margin-bottom:1rem;background:hsl(0 60% 50% / 0.1);border:1px solid hsl(0 60% 50% / 0.2);color:hsl(0 60% 60%);font-size:0.875rem">
        ⚠️ <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <form method="POST" style="display:flex;flex-direction:column;gap:1.25rem">
      <div>
        <label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.5rem">E-mail</label>
        <input type="email" name="email" class="glass-input" placeholder="seu@email.com" required style="padding-left:2.75rem">
      </div>
      <div>
        <label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.5rem">Senha</label>
        <input type="password" name="password" class="glass-input" placeholder="••••••••" required style="padding-left:2.75rem">
      </div>
      <button type="submit" class="btn-primary w-full" style="padding:0.875rem;background:linear-gradient(135deg,hsl(245 60% 50%),hsl(265 60% 55%))">
        ENTRAR →
      </button>
    </form>
    <p class="text-xs text-muted" style="text-align:center;margin-top:1.5rem">Dificuldades no acesso? Contatar o suporte</p>
  </div>
</div>
</body>
</html>
