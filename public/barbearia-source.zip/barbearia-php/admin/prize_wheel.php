<?php
require_once __DIR__ . '/../config.php';
$token = $_SESSION['admin_token'] ?? '';
$settings = get_settings();
$wheelEnabled = ($settings['prize_wheel_enabled'] ?? '') === 'true';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'toggle') {
        $newVal = $wheelEnabled ? 'false' : 'true';
        supabase_request("business_settings?key=eq.prize_wheel_enabled", 'PATCH', ['value' => $newVal], $token);
        $check = supabase_request("business_settings?key=eq.prize_wheel_enabled", 'GET', null, $token);
        if (empty($check['data'])) supabase_request('business_settings', 'POST', ['key' => 'prize_wheel_enabled', 'value' => $newVal], $token);
        header('Location: prize_wheel.php'); exit;
    }
    if ($action === 'save') {
        $payload = [
            'label' => $_POST['label'] ?? '', 'icon' => $_POST['icon'] ?? '🎁',
            'image_url' => $_POST['image_url'] ?: null,
            'discount_percent' => (float)($_POST['discount_percent'] ?? 0) ?: null,
            'discount_value' => (float)($_POST['discount_value'] ?? 0) ?: null,
            'custom_prize' => $_POST['custom_prize'] ?: null,
            'probability' => (int)($_POST['probability'] ?? 10),
            'active' => isset($_POST['active']), 'sort_order' => (int)($_POST['sort_order'] ?? 0),
        ];
        $id = $_POST['id'] ?? '';
        if ($id) supabase_request("prize_wheel_slices?id=eq.$id", 'PATCH', $payload, $token);
        else supabase_request('prize_wheel_slices', 'POST', $payload, $token);
        header('Location: prize_wheel.php'); exit;
    }
    if ($action === 'delete') { supabase_request("prize_wheel_slices?id=eq.{$_POST['id']}", 'DELETE', null, $token); header('Location: prize_wheel.php'); exit; }
}

$slices = (supabase_request('prize_wheel_slices?order=sort_order', 'GET', null, $token))['data'] ?? [];
require 'includes/admin_header.php';
?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
  <div style="display:flex;align-items:center;gap:0.75rem;">
    <h2 style="font-size:1.125rem;font-weight:700;">Roleta Premiada</h2>
    <form method="post" style="display:inline;"><input type="hidden" name="action" value="toggle">
      <button type="submit" class="toggle <?= $wheelEnabled ? 'on' : 'off' ?>"><span class="toggle-knob"></span></button>
    </form>
  </div>
  <button class="btn-accent" onclick="openModal('prizeModal')" style="font-size:0.75rem;">➕ Novo Prêmio</button>
</div>

<?php foreach ($slices as $s): ?>
<div class="glass-card list-item">
  <div class="list-thumb-placeholder" style="background:hsl(245,60%,55%,0.1);overflow:hidden;">
    <?php if (!empty($s['image_url'])): ?><img src="<?= htmlspecialchars($s['image_url']) ?>" style="width:100%;height:100%;object-fit:cover;"><?php else: ?><span style="font-size:1.5rem;"><?= $s['icon'] ?></span><?php endif; ?>
  </div>
  <div class="list-info">
    <div style="display:flex;align-items:center;gap:0.5rem;"><span class="list-title"><?= htmlspecialchars($s['label']) ?></span><?php if (!$s['active']): ?><span class="badge badge-inactive">Inativo</span><?php endif; ?></div>
    <div style="display:flex;align-items:center;gap:0.75rem;margin-top:0.125rem;">
      <?php if ($s['discount_percent']): ?><span style="font-size:0.75rem;color:hsl(245,60%,70%);"><?= intval($s['discount_percent']) ?>% desc.</span><?php endif; ?>
      <?php if ($s['discount_value']): ?><span style="font-size:0.75rem;color:hsl(245,60%,70%);">R$ <?= number_format($s['discount_value'], 2, ',', '.') ?> desc.</span><?php endif; ?>
      <?php if ($s['custom_prize']): ?><span style="font-size:0.75rem;color:var(--muted-foreground);"><?= htmlspecialchars($s['custom_prize']) ?></span><?php endif; ?>
      <span style="font-size:0.625rem;color:var(--muted-foreground);">Prob: <?= $s['probability'] ?></span>
    </div>
  </div>
  <div class="list-actions">
    <button class="btn-edit" onclick="editPrize(<?= htmlspecialchars(json_encode($s)) ?>)">✏</button>
    <form method="post" style="display:inline;" onsubmit="return confirm('Excluir?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $s['id'] ?>"><button type="submit" class="btn-delete">🗑</button></form>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($slices)): ?><div class="glass-card" style="padding:2rem;text-align:center;"><span style="font-size:2rem;display:block;margin-bottom:0.5rem;">🎁</span><p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum prêmio configurado</p></div><?php endif; ?>

<div class="modal-overlay" id="prizeModal" style="display:none;">
  <div class="glass-card-strong modal-content">
    <div class="modal-header"><h3 id="prizeModalTitle">Novo Prêmio</h3><button class="modal-close" onclick="closeModal('prizeModal')">✕</button></div>
    <form method="post">
      <input type="hidden" name="action" value="save"><input type="hidden" name="id" id="pw_id">
      <div class="form-group"><label class="form-label">Nome *</label><input class="glass-input" name="label" id="pw_label" required placeholder="Ex: 10% OFF"></div>
      <div class="form-group"><label class="form-label">URL da Imagem</label><input class="glass-input" name="image_url" id="pw_image" placeholder="https://..."></div>
      <div class="form-group"><label class="form-label">Ícone (fallback)</label><input class="glass-input" name="icon" id="pw_icon" value="🎁" placeholder="🎁"></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Desconto %</label><input class="glass-input" name="discount_percent" id="pw_pct" type="number" min="0" max="100" value="0"></div>
        <div class="form-group"><label class="form-label">Desconto R$</label><input class="glass-input" name="discount_value" id="pw_val" type="number" min="0" step="0.01" value="0"></div>
      </div>
      <div class="form-group"><label class="form-label">Prêmio personalizado</label><input class="glass-input" name="custom_prize" id="pw_custom" placeholder="Ex: Corte grátis"></div>
      <div class="form-group"><label class="form-label">Probabilidade (peso)</label><input class="glass-input" name="probability" id="pw_prob" type="number" min="1" max="100" value="10"><p style="font-size:0.625rem;color:var(--muted-foreground);margin-top:0.25rem;">Quanto maior, mais chance</p></div>
      <input type="hidden" name="sort_order" id="pw_order" value="0">
      <div class="form-group" style="display:flex;align-items:center;gap:0.75rem;"><label class="form-label" style="margin:0;">Ativo</label><input type="checkbox" name="active" id="pw_active" checked></div>
      <button type="submit" class="btn-accent" style="width:100%;justify-content:center;">💾 Salvar</button>
    </form>
  </div>
</div>
<script>
function editPrize(s) {
  document.getElementById('prizeModalTitle').textContent = 'Editar Prêmio';
  document.getElementById('pw_id').value = s.id;
  document.getElementById('pw_label').value = s.label;
  document.getElementById('pw_image').value = s.image_url || '';
  document.getElementById('pw_icon').value = s.icon || '🎁';
  document.getElementById('pw_pct').value = s.discount_percent || 0;
  document.getElementById('pw_val').value = s.discount_value || 0;
  document.getElementById('pw_custom').value = s.custom_prize || '';
  document.getElementById('pw_prob').value = s.probability || 10;
  document.getElementById('pw_order').value = s.sort_order || 0;
  document.getElementById('pw_active').checked = s.active;
  openModal('prizeModal');
}
</script>
<?php require 'includes/admin_footer.php'; ?>