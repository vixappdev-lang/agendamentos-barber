<?php
require_once __DIR__ . '/../config.php';
$token = $_SESSION['admin_token'] ?? '';
$settings = get_settings();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $keys = ['business_name','address','whatsapp_number','opening_time','closing_time','lunch_start','lunch_end','days_off','location_lat','location_lng'];
    foreach ($keys as $key) {
        $value = $_POST[$key] ?? '';
        supabase_request("business_settings?key=eq.$key", 'PATCH', ['value' => $value], $token);
        // Upsert: if not exists, insert
        $check = supabase_request("business_settings?key=eq.$key", 'GET', null, $token);
        if (empty($check['data'])) supabase_request('business_settings', 'POST', ['key' => $key, 'value' => $value], $token);
    }
    header('Location: settings.php?saved=1'); exit;
}
$saved = isset($_GET['saved']);
$dayLabels = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
$daysOff = array_filter(explode(',', $settings['days_off'] ?? ''));
require 'includes/admin_header.php';
?>
<?php if ($saved): ?>
<div class="glass-card" style="padding:0.75rem;margin-bottom:1rem;border-color:hsl(140,60%,50%,0.3);text-align:center;">
  <p style="font-size:0.875rem;color:hsl(140,60%,55%);">✅ Configurações salvas com sucesso!</p>
</div>
<?php endif; ?>

<form method="post">
  <div class="grid-cols-2-lg" style="margin-bottom:1rem;">
    <div class="glass-card" style="padding:1.25rem;">
      <h3 style="font-size:0.875rem;font-weight:600;margin-bottom:1.25rem;">🏪 Dados da Barbearia</h3>
      <div class="form-group"><label class="form-label">Nome da Barbearia</label><input class="glass-input" name="business_name" value="<?= htmlspecialchars($settings['business_name'] ?? '') ?>"></div>
      <div class="form-group"><label class="form-label">📍 Endereço</label><input class="glass-input" name="address" value="<?= htmlspecialchars($settings['address'] ?? '') ?>"></div>
      <div class="form-group"><label class="form-label">📱 WhatsApp (com DDI+DDD)</label><input class="glass-input" name="whatsapp_number" value="<?= htmlspecialchars($settings['whatsapp_number'] ?? '') ?>" placeholder="5511999999999"></div>
      <input type="hidden" name="location_lat" value="<?= htmlspecialchars($settings['location_lat'] ?? '') ?>">
      <input type="hidden" name="location_lng" value="<?= htmlspecialchars($settings['location_lng'] ?? '') ?>">
    </div>
    <div>
      <div class="glass-card" style="padding:1.25rem;margin-bottom:1rem;">
        <h3 style="font-size:0.875rem;font-weight:600;margin-bottom:1.25rem;">🕐 Horário de Funcionamento</h3>
        <div class="grid-2">
          <div class="form-group"><label class="form-label">Abertura</label><input type="time" class="glass-input" name="opening_time" value="<?= htmlspecialchars($settings['opening_time'] ?? '09:00') ?>"></div>
          <div class="form-group"><label class="form-label">Fechamento</label><input type="time" class="glass-input" name="closing_time" value="<?= htmlspecialchars($settings['closing_time'] ?? '19:00') ?>"></div>
          <div class="form-group"><label class="form-label">Início Almoço</label><input type="time" class="glass-input" name="lunch_start" value="<?= htmlspecialchars($settings['lunch_start'] ?? '12:00') ?>"></div>
          <div class="form-group"><label class="form-label">Fim Almoço</label><input type="time" class="glass-input" name="lunch_end" value="<?= htmlspecialchars($settings['lunch_end'] ?? '13:00') ?>"></div>
        </div>
      </div>
      <div class="glass-card" style="padding:1.25rem;">
        <h3 style="font-size:0.875rem;font-weight:600;margin-bottom:1rem;">📅 Dias de Folga</h3>
        <div class="days-bar">
          <?php foreach ($dayLabels as $i => $label): ?>
            <label class="day-btn <?= in_array((string)$i, $daysOff) ? 'off' : '' ?>" style="cursor:pointer;text-align:center;">
              <input type="checkbox" name="days_off_arr[]" value="<?= $i ?>" <?= in_array((string)$i, $daysOff) ? 'checked' : '' ?> style="display:none;" onchange="this.parentElement.classList.toggle('off')">
              <?= $label ?>
            </label>
          <?php endforeach; ?>
        </div>
        <p style="font-size:0.625rem;color:var(--muted-foreground);margin-top:0.5rem;">Clique nos dias em que a barbearia não funciona</p>
        <input type="hidden" name="days_off" id="days_off_hidden">
      </div>
    </div>
  </div>
  <button type="submit" class="btn-accent" style="width:100%;justify-content:center;padding:0.875rem;" onclick="document.getElementById('days_off_hidden').value=Array.from(document.querySelectorAll('input[name=\'days_off_arr[]\']\:checked')).map(e=>e.value).join(',');">
    💾 Salvar Configurações
  </button>
</form>
<?php require 'includes/admin_footer.php'; ?>