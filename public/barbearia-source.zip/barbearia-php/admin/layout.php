<?php
$page = $page ?? $_GET['page'] ?? 'dashboard';
$navItems = [
    ['dashboard', 'Dashboard', '📊'],
    ['services', 'Serviços', '✂️'],
    ['store', 'Loja', '🛍️'],
    ['barbers', 'Barbeiros', '👥'],
    ['appointments', 'Agendamentos', '📅'],
    ['coupons', 'Cupons', '🏷️'],
    ['prize-wheel', 'Roleta', '🎁'],
    ['settings', 'Configurações', '⚙️'],
];

$greeting = '';
$hour = (int)date('G');
if ($hour >= 5 && $hour < 12) $greeting = 'Bom dia';
elseif ($hour >= 12 && $hour < 18) $greeting = 'Boa tarde';
elseif ($hour >= 18) $greeting = 'Boa noite';
else $greeting = 'Boa madrugada';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - <?= ucfirst($page) ?></title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div style="display:flex;min-height:100vh">
  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div style="padding:1.25rem;border-bottom:1px solid var(--glass-border);display:flex;align-items:center;gap:0.5rem">
      <div style="width:2rem;height:2rem;border-radius:0.5rem;display:flex;align-items:center;justify-content:center;background:hsl(245 60% 55% / 0.15);border:1px solid hsl(245 60% 55% / 0.3)">✂️</div>
      <span class="font-bold text-sm">Admin Panel</span>
    </div>
    <nav style="flex:1;padding:0.75rem;display:flex;flex-direction:column;gap:0.25rem">
      <?php foreach ($navItems as $item): ?>
        <a href="index.php?page=<?= $item[0] ?>" class="admin-nav-item <?= $page === $item[0] ? 'active' : '' ?>">
          <span><?= $item[2] ?></span> <?= $item[1] ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div style="padding:0.75rem;border-top:1px solid var(--glass-border)">
      <a href="logout.php" class="admin-nav-item" style="color:hsl(0 60% 60%)">🚪 Sair</a>
    </div>
  </aside>

  <!-- Main -->
  <div style="flex:1;display:flex;flex-direction:column;min-width:0">
    <header style="position:sticky;top:0;z-index:30;display:flex;align-items:center;gap:0.75rem;padding:1rem 1.5rem;background:hsl(230 20% 5% / 0.8);backdrop-filter:blur(12px);border-bottom:1px solid var(--glass-border)">
      <h1 style="font-size:1.25rem;font-weight:700">
        <?= $page === 'dashboard' ? "$greeting, Admin." : ucfirst(str_replace('-', ' ', $page)) ?>
      </h1>
    </header>
    <main class="admin-content">
      <?php include "pages/$page.php"; ?>
    </main>
  </div>
</div>
</body>
</html>
