<?php
$token = getAdminToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    if ($action === 'create' || $action === 'update') {
        $payload = [
            'title' => $_POST['title'] ?? '',
            'subtitle' => $_POST['subtitle'] ?: null,
            'price' => floatval($_POST['price'] ?? 0),
            'duration' => $_POST['duration'] ?? '',
            'image_url' => $_POST['image_url'] ?: null,
            'active' => isset($_POST['active']),
            'sort_order' => intval($_POST['sort_order'] ?? 0),
        ];
        if ($action === 'update' && !empty($_POST['id'])) {
            supabaseRequest('services?id=eq.' . urlencode($_POST['id']), 'PATCH', $payload, $token);
        } else {
            supabaseRequest('services', 'POST', $payload, $token);
        }
    } elseif ($action === 'delete' && !empty($_POST['id'])) {
        supabaseRequest('services?id=eq.' . urlencode($_POST['id']), 'DELETE', null, $token);
    }
    header('Location: index.php?page=services'); exit;
}

$services = supabaseRequest('services?select=*&order=sort_order.asc', 'GET', null, $token) ?: [];
?>
<div class="flex-between mb-4">
  <h2 class="text-lg font-bold">Serviços</h2>
  <button onclick="document.getElementById('serviceModal').style.display='flex'" class="btn-primary" style="padding:0.5rem 1rem;font-size:0.75rem">＋ Novo Serviço</button>
</div>

<div style="display:flex;flex-direction:column;gap:0.75rem">
  <?php foreach ($services as $s): ?>
    <div class="glass-card" style="padding:1rem;display:flex;align-items:center;gap:1rem">
      <div style="width:3.5rem;height:3.5rem;border-radius:0.75rem;background:hsl(0 0% 100%/0.05);display:flex;align-items:center;justify-content:center;flex-shrink:0">✂️</div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:0.5rem">
          <h3 class="text-sm font-semibold truncate"><?= htmlspecialchars($s['title']) ?></h3>
          <?php if (!$s['active']): ?><span class="badge badge-cancelled">Inativo</span><?php endif; ?>
        </div>
        <p class="text-xs text-muted truncate"><?= htmlspecialchars($s['subtitle'] ?? '') ?></p>
        <div style="display:flex;gap:0.75rem;margin-top:0.25rem;align-items:center">
          <span class="text-sm font-bold text-accent">R$ <?= number_format($s['price'], 2, ',', '.') ?></span>
          <span class="text-xs text-muted"><?= htmlspecialchars($s['duration']) ?></span>
        </div>
      </div>
      <form method="POST" style="display:inline" onsubmit="return confirm('Excluir este serviço?')">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="<?= $s['id'] ?>">
        <button type="submit" class="btn-danger">🗑️</button>
      </form>
    </div>
  <?php endforeach; ?>
  <?php if (empty($services)): ?>
    <div class="glass-card p-5" style="text-align:center"><p class="text-sm text-muted">Nenhum serviço cadastrado</p></div>
  <?php endif; ?>
</div>

<!-- Modal -->
<div id="serviceModal" class="modal-overlay" style="display:none" onclick="if(event.target===this)this.style.display='none'">
  <form method="POST" class="glass-card-strong modal-content" style="padding:1.5rem">
    <div class="flex-between mb-4">
      <h3 class="font-bold">Novo Serviço</h3>
      <button type="button" onclick="this.closest('.modal-overlay').style.display='none'" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.25rem">✕</button>
    </div>
    <input type="hidden" name="action" value="create">
    <div style="display:flex;flex-direction:column;gap:0.75rem">
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Nome *</label><input name="title" class="glass-input" required></div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Descrição</label><input name="subtitle" class="glass-input"></div>
      <div class="grid-2">
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Preço (R$) *</label><input name="price" type="number" step="0.01" class="glass-input" required></div>
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Duração *</label><input name="duration" class="glass-input" placeholder="40 min" required></div>
      </div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">URL da Imagem</label><input name="image_url" class="glass-input"></div>
      <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer"><input type="checkbox" name="active" checked style="accent-color:var(--accent)"> <span class="text-sm">Ativo</span></label>
      <input type="hidden" name="sort_order" value="0">
    </div>
    <button type="submit" class="btn-primary w-full" style="margin-top:1rem">Criar Serviço</button>
  </form>
</div>
