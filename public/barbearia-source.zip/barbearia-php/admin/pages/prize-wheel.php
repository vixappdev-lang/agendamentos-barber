<?php
$token = getAdminToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create') {
        supabaseRequest('prize_wheel_slices', 'POST', [
            'label' => $_POST['label'] ?? '', 'icon' => $_POST['icon'] ?? '🎁',
            'discount_percent' => floatval($_POST['discount_percent'] ?? 0) ?: null,
            'discount_value' => floatval($_POST['discount_value'] ?? 0) ?: null,
            'custom_prize' => $_POST['custom_prize'] ?: null,
            'probability' => intval($_POST['probability'] ?? 10),
            'active' => isset($_POST['active']), 'sort_order' => intval($_POST['sort_order'] ?? 0),
        ], $token);
    } elseif ($_POST['action'] === 'delete' && !empty($_POST['id'])) {
        supabaseRequest('prize_wheel_slices?id=eq.' . urlencode($_POST['id']), 'DELETE', null, $token);
    } elseif ($_POST['action'] === 'toggle') {
        $current = getSettings()['prize_wheel_enabled'] ?? 'false';
        $newVal = $current === 'true' ? 'false' : 'true';
        supabaseRequest('business_settings?key=eq.prize_wheel_enabled', 'PATCH', ['value' => $newVal], $token);
    }
    header('Location: index.php?page=prize-wheel'); exit;
}
$slices = supabaseRequest('prize_wheel_slices?select=*&order=sort_order.asc', 'GET', null, $token) ?: [];
$wheelEnabled = (getSettings()['prize_wheel_enabled'] ?? 'false') === 'true';
?>
<div class="flex-between mb-4">
  <div style="display:flex;align-items:center;gap:0.75rem">
    <h2 class="text-lg font-bold">Roleta Premiada</h2>
    <form method="POST" style="display:inline"><input type="hidden" name="action" value="toggle">
      <button type="submit" class="toggle <?= $wheelEnabled ? 'on' : 'off' ?>"><div class="toggle-dot"></div></button>
    </form>
  </div>
  <button onclick="document.getElementById('prizeModal').style.display='flex'" class="btn-primary" style="padding:0.5rem 1rem;font-size:0.75rem">＋ Novo Prêmio</button>
</div>

<div style="display:flex;flex-direction:column;gap:0.75rem">
  <?php foreach ($slices as $s): ?>
    <div class="glass-card" style="padding:1rem;display:flex;align-items:center;gap:1rem">
      <div style="width:3rem;height:3rem;border-radius:0.75rem;display:flex;align-items:center;justify-content:center;font-size:1.5rem;background:hsl(245 60% 55%/0.1)"><?= $s['icon'] ?></div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:0.5rem">
          <h3 class="text-sm font-semibold truncate"><?= htmlspecialchars($s['label']) ?></h3>
          <?php if (!$s['active']): ?><span class="badge badge-cancelled">Inativo</span><?php endif; ?>
        </div>
        <div style="display:flex;gap:0.75rem;margin-top:0.125rem;font-size:0.75rem">
          <?php if ($s['discount_percent']): ?><span class="text-accent"><?= intval($s['discount_percent']) ?>% desc.</span><?php endif; ?>
          <?php if ($s['discount_value']): ?><span class="text-accent">R$ <?= number_format($s['discount_value'], 2, ',', '.') ?> desc.</span><?php endif; ?>
          <?php if ($s['custom_prize']): ?><span class="text-muted"><?= htmlspecialchars($s['custom_prize']) ?></span><?php endif; ?>
          <span class="text-muted" style="font-size:0.625rem">Prob: <?= $s['probability'] ?></span>
        </div>
      </div>
      <form method="POST" style="display:inline" onsubmit="return confirm('Excluir?')">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $s['id'] ?>">
        <button type="submit" class="btn-danger">🗑️</button>
      </form>
    </div>
  <?php endforeach; ?>
  <?php if (empty($slices)): ?><div class="glass-card p-5" style="text-align:center"><p class="text-sm text-muted">🎁 Nenhum prêmio configurado</p></div><?php endif; ?>
</div>

<div id="prizeModal" class="modal-overlay" style="display:none" onclick="if(event.target===this)this.style.display='none'">
  <form method="POST" class="glass-card-strong modal-content" style="padding:1.5rem">
    <div class="flex-between mb-4"><h3 class="font-bold">Novo Prêmio</h3><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.25rem">✕</button></div>
    <input type="hidden" name="action" value="create">
    <div style="display:flex;flex-direction:column;gap:0.75rem">
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Nome *</label><input name="label" class="glass-input" required></div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Ícone Emoji</label><input name="icon" class="glass-input" value="🎁"></div>
      <div class="grid-2">
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Desconto %</label><input name="discount_percent" type="number" class="glass-input" value="0"></div>
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Desconto R$</label><input name="discount_value" type="number" step="0.01" class="glass-input" value="0"></div>
      </div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Prêmio personalizado</label><input name="custom_prize" class="glass-input" placeholder="Ex: Corte grátis"></div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Probabilidade (peso)</label><input name="probability" type="number" min="1" class="glass-input" value="10"></div>
      <label style="display:flex;align-items:center;gap:0.5rem"><input type="checkbox" name="active" checked style="accent-color:var(--accent)"> <span class="text-sm">Ativo</span></label>
      <input type="hidden" name="sort_order" value="0">
    </div>
    <button type="submit" class="btn-primary w-full" style="margin-top:1rem">Criar Prêmio</button>
  </form>
</div>
