<?php
$token = getAdminToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create') {
        supabaseRequest('coupons', 'POST', [
            'code' => strtoupper($_POST['code'] ?? ''),
            'discount_percent' => floatval($_POST['discount_percent'] ?? 0) ?: null,
            'discount_value' => floatval($_POST['discount_value'] ?? 0) ?: null,
            'active' => isset($_POST['active']),
            'max_uses' => intval($_POST['max_uses'] ?? 0) ?: null,
            'expires_at' => !empty($_POST['expires_at']) ? $_POST['expires_at'] . 'T23:59:59Z' : null,
        ], $token);
    } elseif ($_POST['action'] === 'delete' && !empty($_POST['id'])) {
        supabaseRequest('coupons?id=eq.' . urlencode($_POST['id']), 'DELETE', null, $token);
    }
    header('Location: index.php?page=coupons'); exit;
}
$coupons = supabaseRequest('coupons?select=*&order=created_at.desc', 'GET', null, $token) ?: [];
?>
<div class="flex-between mb-4">
  <h2 class="text-lg font-bold">Cupons</h2>
  <button onclick="document.getElementById('couponModal').style.display='flex'" class="btn-primary" style="padding:0.5rem 1rem;font-size:0.75rem">＋ Novo Cupom</button>
</div>
<div style="display:flex;flex-direction:column;gap:0.75rem">
  <?php foreach ($coupons as $c): ?>
    <div class="glass-card" style="padding:1rem;display:flex;align-items:center;gap:1rem">
      <div style="width:2.5rem;height:2.5rem;border-radius:0.75rem;display:flex;align-items:center;justify-content:center;background:hsl(245 60% 55%/0.12)">🏷️</div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:0.5rem">
          <h3 class="text-sm font-bold" style="letter-spacing:0.1em"><?= htmlspecialchars($c['code']) ?></h3>
          <?php if (!$c['active']): ?><span class="badge badge-cancelled">Inativo</span><?php endif; ?>
        </div>
        <div style="display:flex;gap:0.75rem;margin-top:0.125rem;font-size:0.75rem;color:var(--muted)">
          <span style="color:hsl(160 60% 55%);font-weight:600"><?= $c['discount_percent'] ? intval($c['discount_percent']).'% off' : 'R$ '.number_format($c['discount_value'] ?? 0, 2, ',', '.').' off' ?></span>
          <?php if ($c['max_uses']): ?><span><?= $c['current_uses'] ?? 0 ?>/<?= $c['max_uses'] ?> usos</span><?php endif; ?>
          <?php if ($c['expires_at']): ?><span>Exp: <?= date('d/m/Y', strtotime($c['expires_at'])) ?></span><?php endif; ?>
        </div>
      </div>
      <form method="POST" style="display:inline" onsubmit="return confirm('Excluir?')">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $c['id'] ?>">
        <button type="submit" class="btn-danger">🗑️</button>
      </form>
    </div>
  <?php endforeach; ?>
  <?php if (empty($coupons)): ?><div class="glass-card p-5" style="text-align:center"><p class="text-sm text-muted">Nenhum cupom cadastrado</p></div><?php endif; ?>
</div>

<div id="couponModal" class="modal-overlay" style="display:none" onclick="if(event.target===this)this.style.display='none'">
  <form method="POST" class="glass-card-strong modal-content" style="padding:1.5rem">
    <div class="flex-between mb-4"><h3 class="font-bold">Novo Cupom</h3><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.25rem">✕</button></div>
    <input type="hidden" name="action" value="create">
    <div style="display:flex;flex-direction:column;gap:0.75rem">
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Código *</label><input name="code" class="glass-input" style="text-transform:uppercase" required></div>
      <div class="grid-2">
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Desconto %</label><input name="discount_percent" type="number" class="glass-input" value="0"></div>
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Desconto R$</label><input name="discount_value" type="number" step="0.01" class="glass-input" value="0"></div>
      </div>
      <div class="grid-2">
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Validade</label><input name="expires_at" type="date" class="glass-input"></div>
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Limite de Usos</label><input name="max_uses" type="number" class="glass-input" value="0"></div>
      </div>
      <label style="display:flex;align-items:center;gap:0.5rem"><input type="checkbox" name="active" checked style="accent-color:var(--accent)"> <span class="text-sm">Ativo</span></label>
    </div>
    <button type="submit" class="btn-primary w-full" style="margin-top:1rem">Criar Cupom</button>
  </form>
</div>
