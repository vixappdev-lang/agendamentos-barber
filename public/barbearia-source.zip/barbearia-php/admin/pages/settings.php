<?php
$token = getAdminToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $keys = ['business_name', 'address', 'whatsapp_number', 'opening_time', 'closing_time', 'lunch_start', 'lunch_end', 'days_off'];
    foreach ($keys as $key) {
        $val = $_POST[$key] ?? '';
        supabaseRequest('business_settings?key=eq.' . urlencode($key), 'PATCH', ['value' => $val], $token);
    }
    // handle days_off from checkboxes
    $daysOff = implode(',', $_POST['days'] ?? []);
    supabaseRequest('business_settings?key=eq.days_off', 'PATCH', ['value' => $daysOff], $token);

    echo '<div class="glass-card" style="padding:0.75rem 1rem;margin-bottom:1rem;border-color:hsl(160 60% 45%/0.3)"><p style="font-size:0.875rem;color:hsl(160 60% 55%)">✅ Configurações salvas!</p></div>';
}
$settings = getSettings();
$dayLabels = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
$daysOff = array_filter(explode(',', $settings['days_off'] ?? ''));
?>
<h2 class="text-lg font-bold mb-4">Configurações</h2>
<form method="POST">
  <div class="grid-2 mb-4" style="gap:1rem">
    <div class="glass-card p-5" style="display:flex;flex-direction:column;gap:1rem">
      <h3 class="text-sm font-semibold" style="display:flex;align-items:center;gap:0.5rem"><span style="color:var(--accent-light)">🏪</span> Dados da Barbearia</h3>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Nome</label><input name="business_name" class="glass-input" value="<?= htmlspecialchars($settings['business_name'] ?? '') ?>"></div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Endereço</label><input name="address" class="glass-input" value="<?= htmlspecialchars($settings['address'] ?? '') ?>"></div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">WhatsApp (DDI+DDD)</label><input name="whatsapp_number" class="glass-input" value="<?= htmlspecialchars($settings['whatsapp_number'] ?? '') ?>" placeholder="5511999999999"></div>
    </div>
    <div style="display:flex;flex-direction:column;gap:1rem">
      <div class="glass-card p-5" style="display:flex;flex-direction:column;gap:1rem">
        <h3 class="text-sm font-semibold" style="display:flex;align-items:center;gap:0.5rem"><span style="color:var(--accent-light)">🕐</span> Horário</h3>
        <div class="grid-2">
          <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Abertura</label><input type="time" name="opening_time" class="glass-input" value="<?= $settings['opening_time'] ?? '09:00' ?>"></div>
          <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Fechamento</label><input type="time" name="closing_time" class="glass-input" value="<?= $settings['closing_time'] ?? '19:00' ?>"></div>
          <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Início Almoço</label><input type="time" name="lunch_start" class="glass-input" value="<?= $settings['lunch_start'] ?? '12:00' ?>"></div>
          <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Fim Almoço</label><input type="time" name="lunch_end" class="glass-input" value="<?= $settings['lunch_end'] ?? '13:00' ?>"></div>
        </div>
      </div>
      <div class="glass-card p-5">
        <h3 class="text-sm font-semibold mb-4" style="display:flex;align-items:center;gap:0.5rem"><span style="color:var(--accent-light)">📅</span> Dias de Folga</h3>
        <div style="display:flex;gap:0.5rem">
          <?php for ($i = 0; $i < 7; $i++): ?>
            <label style="flex:1;text-align:center;padding:0.625rem;border-radius:0.75rem;cursor:pointer;font-size:0.75rem;font-weight:600;<?= in_array((string)$i, $daysOff) ? 'background:hsl(0 60% 50%/0.15);color:hsl(0 60% 65%);border:1px solid hsl(0 60% 50%/0.3)' : 'background:var(--glass);color:hsl(0 0% 55%);border:1px solid var(--glass-border)' ?>">
              <input type="checkbox" name="days[]" value="<?= $i ?>" <?= in_array((string)$i, $daysOff) ? 'checked' : '' ?> style="display:none">
              <?= $dayLabels[$i] ?>
            </label>
          <?php endfor; ?>
        </div>
        <p class="text-xs text-muted" style="margin-top:0.5rem">Clique nos dias em que a barbearia não funciona</p>
      </div>
    </div>
  </div>
  <button type="submit" class="btn-primary w-full" style="padding:0.875rem;background:linear-gradient(135deg,hsl(245 60% 50%),hsl(265 60% 55%))">💾 Salvar Configurações</button>
</form>
