<?php
$token = getAdminToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status' && !empty($_POST['id'])) {
        supabaseRequest('appointments?id=eq.' . urlencode($_POST['id']), 'PATCH', ['status' => $_POST['status']], $token);
    }
    header('Location: index.php?page=appointments'); exit;
}
$appointments = supabaseRequest('appointments?select=*,services(title)&order=appointment_date.desc,appointment_time.asc', 'GET', null, $token) ?: [];
$statusMap = [
    'pending' => ['Pendente', 'badge-pending'], 'confirmed' => ['Confirmado', 'badge-confirmed'],
    'completed' => ['Concluído', 'badge-completed'], 'cancelled' => ['Cancelado', 'badge-cancelled'],
];
?>
<h2 class="text-lg font-bold mb-4">Agendamentos</h2>
<div style="display:flex;flex-direction:column;gap:0.5rem">
  <?php foreach ($appointments as $a):
    $st = $statusMap[$a['status'] ?? 'pending'] ?? $statusMap['pending'];
    $svcTitle = $a['services']['title'] ?? '';
  ?>
    <div class="glass-card p-4">
      <div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap">
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap">
            <h3 class="text-sm font-semibold"><?= htmlspecialchars($a['customer_name']) ?></h3>
            <span class="badge <?= $st[1] ?>"><?= $st[0] ?></span>
          </div>
          <div style="display:flex;gap:0.75rem;margin-top:0.25rem;font-size:0.75rem;color:var(--muted);flex-wrap:wrap">
            <span>📅 <?= date('d/m/Y', strtotime($a['appointment_date'])) ?></span>
            <span>🕐 <?= substr($a['appointment_time'], 0, 5) ?></span>
            <?php if ($svcTitle): ?><span><?= htmlspecialchars($svcTitle) ?></span><?php endif; ?>
            <?php if ($a['barber_name']): ?><span>• <?= htmlspecialchars($a['barber_name']) ?></span><?php endif; ?>
          </div>
        </div>
        <?php if ($a['total_price']): ?>
          <span class="text-sm font-bold text-accent">R$ <?= number_format($a['total_price'], 2, ',', '.') ?></span>
        <?php endif; ?>
        <div style="display:flex;gap:0.25rem">
          <?php if (($a['status'] ?? 'pending') !== 'completed'): ?>
            <form method="POST" style="display:inline"><input type="hidden" name="action" value="update_status"><input type="hidden" name="id" value="<?= $a['id'] ?>"><input type="hidden" name="status" value="completed">
              <button type="submit" style="padding:0.5rem;border-radius:0.5rem;background:hsl(160 60% 45%/0.1);border:none;cursor:pointer;color:hsl(160 60% 55%)" title="Concluir">✓</button>
            </form>
          <?php endif; ?>
          <?php if (($a['status'] ?? 'pending') !== 'cancelled'): ?>
            <form method="POST" style="display:inline"><input type="hidden" name="action" value="update_status"><input type="hidden" name="id" value="<?= $a['id'] ?>"><input type="hidden" name="status" value="cancelled">
              <button type="submit" style="padding:0.5rem;border-radius:0.5rem;background:hsl(0 60% 50%/0.1);border:none;cursor:pointer;color:hsl(0 60% 55%)" title="Cancelar">✕</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (empty($appointments)): ?><div class="glass-card p-5" style="text-align:center"><p class="text-sm text-muted">Nenhum agendamento encontrado</p></div><?php endif; ?>
</div>
