<?php
$token = getAdminToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create_product') {
        supabaseRequest('products', 'POST', [
            'title' => $_POST['title'] ?? '', 'description' => $_POST['description'] ?: null,
            'price' => floatval($_POST['price'] ?? 0), 'image_url' => $_POST['image_url'] ?: null,
            'active' => isset($_POST['active']), 'sort_order' => intval($_POST['sort_order'] ?? 0),
        ], $token);
    } elseif ($_POST['action'] === 'delete_product' && !empty($_POST['id'])) {
        supabaseRequest('products?id=eq.' . urlencode($_POST['id']), 'DELETE', null, $token);
    } elseif ($_POST['action'] === 'save_settings') {
        $keys = ['store_enabled', 'store_order_mode', 'pix_key', 'pix_type'];
        foreach ($keys as $k) {
            $val = $_POST[$k] ?? '';
            supabaseRequest('business_settings?key=eq.' . urlencode($k), 'PATCH', ['value' => $val], $token);
        }
    } elseif ($_POST['action'] === 'update_order_status' && !empty($_POST['id'])) {
        supabaseRequest('orders?id=eq.' . urlencode($_POST['id']), 'PATCH', ['status' => $_POST['status']], $token);
    }
    header('Location: index.php?page=store'); exit;
}
$products = supabaseRequest('products?select=*&order=sort_order.asc', 'GET', null, $token) ?: [];
$orders = supabaseRequest('orders?select=*&order=created_at.desc&limit=50', 'GET', null, $token) ?: [];
$settings = getSettings();
$subtab = $_GET['subtab'] ?? 'products';
?>
<h2 class="text-lg font-bold mb-4">Loja</h2>

<div style="display:flex;gap:0.5rem;margin-bottom:1rem">
  <a href="?page=store&subtab=products" class="cat-btn <?= $subtab === 'products' ? 'active' : '' ?>">🛍️ Produtos</a>
  <a href="?page=store&subtab=orders" class="cat-btn <?= $subtab === 'orders' ? 'active' : '' ?>">📦 Pedidos</a>
  <a href="?page=store&subtab=config" class="cat-btn <?= $subtab === 'config' ? 'active' : '' ?>">⚙️ Config</a>
</div>

<?php if ($subtab === 'products'): ?>
  <div class="flex-between mb-4">
    <span></span>
    <button onclick="document.getElementById('productModal').style.display='flex'" class="btn-primary" style="padding:0.5rem 1rem;font-size:0.75rem">＋ Novo Produto</button>
  </div>
  <div style="display:flex;flex-direction:column;gap:0.75rem">
    <?php foreach ($products as $p): ?>
      <div class="glass-card" style="padding:1rem;display:flex;align-items:center;gap:1rem">
        <div style="width:3.5rem;height:3.5rem;border-radius:0.75rem;background:hsl(0 0% 100%/0.05);display:flex;align-items:center;justify-content:center;flex-shrink:0">🛍️</div>
        <div style="flex:1;min-width:0">
          <h3 class="text-sm font-semibold truncate"><?= htmlspecialchars($p['title']) ?></h3>
          <p class="text-xs text-muted truncate"><?= htmlspecialchars($p['description'] ?? '') ?></p>
          <span class="text-sm font-bold text-accent">R$ <?= number_format($p['price'], 2, ',', '.') ?></span>
        </div>
        <form method="POST" style="display:inline" onsubmit="return confirm('Excluir?')">
          <input type="hidden" name="action" value="delete_product"><input type="hidden" name="id" value="<?= $p['id'] ?>">
          <button type="submit" class="btn-danger">🗑️</button>
        </form>
      </div>
    <?php endforeach; ?>
    <?php if (empty($products)): ?><div class="glass-card p-5" style="text-align:center"><p class="text-sm text-muted">Nenhum produto cadastrado</p></div><?php endif; ?>
  </div>

  <div id="productModal" class="modal-overlay" style="display:none" onclick="if(event.target===this)this.style.display='none'">
    <form method="POST" class="glass-card-strong modal-content" style="padding:1.5rem">
      <div class="flex-between mb-4"><h3 class="font-bold">Novo Produto</h3><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.25rem">✕</button></div>
      <input type="hidden" name="action" value="create_product">
      <div style="display:flex;flex-direction:column;gap:0.75rem">
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Nome *</label><input name="title" class="glass-input" required></div>
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Descrição</label><input name="description" class="glass-input"></div>
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Preço (R$) *</label><input name="price" type="number" step="0.01" class="glass-input" required></div>
        <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">URL da Imagem</label><input name="image_url" class="glass-input"></div>
        <label style="display:flex;align-items:center;gap:0.5rem"><input type="checkbox" name="active" checked style="accent-color:var(--accent)"> <span class="text-sm">Ativo</span></label>
        <input type="hidden" name="sort_order" value="0">
      </div>
      <button type="submit" class="btn-primary w-full" style="margin-top:1rem">Criar Produto</button>
    </form>
  </div>

<?php elseif ($subtab === 'orders'): ?>
  <div style="display:flex;flex-direction:column;gap:0.5rem">
    <?php foreach ($orders as $o):
      $statusMap = ['pending' => ['Pendente', 'badge-pending'], 'confirmed' => ['Confirmado', 'badge-confirmed'], 'preparing' => ['Preparando', 'badge-confirmed'], 'delivering' => ['Entregando', 'badge-pending'], 'completed' => ['Concluído', 'badge-completed'], 'cancelled' => ['Cancelado', 'badge-cancelled']];
      $st = $statusMap[$o['status']] ?? $statusMap['pending'];
    ?>
      <div class="glass-card p-4">
        <div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap">
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:0.5rem"><h3 class="text-sm font-semibold"><?= htmlspecialchars($o['customer_name']) ?></h3><span class="badge <?= $st[1] ?>"><?= $st[0] ?></span></div>
            <div style="font-size:0.75rem;color:var(--muted);margin-top:0.25rem">📅 <?= date('d/m/Y H:i', strtotime($o['created_at'])) ?> • <?= $o['delivery_mode'] ?></div>
          </div>
          <span class="text-sm font-bold text-accent">R$ <?= number_format($o['total_price'], 2, ',', '.') ?></span>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (empty($orders)): ?><div class="glass-card p-5" style="text-align:center"><p class="text-sm text-muted">Nenhum pedido</p></div><?php endif; ?>
  </div>

<?php elseif ($subtab === 'config'): ?>
  <form method="POST" class="glass-card p-5" style="display:flex;flex-direction:column;gap:1rem">
    <input type="hidden" name="action" value="save_settings">
    <div class="flex-between">
      <div><h3 class="text-sm font-semibold">Loja / Marketplace</h3><p class="text-xs text-muted">Ativar seção de produtos</p></div>
      <select name="store_enabled" class="glass-input" style="width:auto"><option value="true" <?= ($settings['store_enabled'] ?? '') === 'true' ? 'selected' : '' ?>>Ativado</option><option value="false" <?= ($settings['store_enabled'] ?? '') !== 'true' ? 'selected' : '' ?>>Desativado</option></select>
    </div>
    <div class="grid-2">
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Modo de Pedido</label><select name="store_order_mode" class="glass-input"><option value="whatsapp" <?= ($settings['store_order_mode'] ?? '') === 'whatsapp' ? 'selected' : '' ?>>Via WhatsApp</option><option value="ifood" <?= ($settings['store_order_mode'] ?? '') === 'ifood' ? 'selected' : '' ?>>Similar ao iFood</option></select></div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Tipo Chave PIX</label><select name="pix_type" class="glass-input"><option value="cpf">CPF</option><option value="cnpj">CNPJ</option><option value="email">Email</option><option value="telefone">Telefone</option><option value="aleatoria">Chave Aleatória</option></select></div>
    </div>
    <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Chave PIX</label><input name="pix_key" class="glass-input" value="<?= htmlspecialchars($settings['pix_key'] ?? '') ?>"></div>
    <button type="submit" class="btn-primary w-full">💾 Salvar Configurações</button>
  </form>
<?php endif; ?>
