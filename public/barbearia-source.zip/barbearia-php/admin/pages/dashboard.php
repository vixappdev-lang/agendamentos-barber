<?php
$appointments = $appointments ?? supabaseRequest('appointments?select=*', 'GET', null, getAdminToken()) ?: [];
$services = $services ?? supabaseRequest('services?select=*', 'GET', null, getAdminToken()) ?: [];
$today = date('Y-m-d');
$todayApps = array_filter($appointments, fn($a) => $a['appointment_date'] === $today);
$totalRevenue = array_sum(array_map(fn($a) => floatval($a['total_price'] ?? 0), $appointments));
$activeServices = count(array_filter($services, fn($s) => $s['active']));

$stats = [
    ['📅', 'Agendamentos Hoje', count($todayApps), 'hsl(245 60% 55%)'],
    ['👥', 'Total Agendamentos', count($appointments), 'hsl(200 70% 50%)'],
    ['💰', 'Receita Total', 'R$ ' . number_format($totalRevenue, 2, ',', '.'), 'hsl(160 60% 45%)'],
    ['✂️', 'Serviços Ativos', $activeServices, 'hsl(280 60% 55%)'],
];
?>
<div class="grid-4 mb-6">
  <?php foreach ($stats as $s): ?>
    <div class="glass-card stat-card">
      <div style="width:2.25rem;height:2.25rem;border-radius:0.75rem;display:flex;align-items:center;justify-content:center;margin-bottom:0.75rem;background:<?= $s[3] ?>20;border:1px solid <?= $s[3] ?>30"><?= $s[0] ?></div>
      <p class="stat-value"><?= $s[2] ?></p>
      <p class="stat-label"><?= $s[1] ?></p>
    </div>
  <?php endforeach; ?>
</div>

<!-- Service Distribution -->
<div class="glass-card p-5">
  <h3 class="text-sm font-semibold mb-4">Distribuição por Serviço</h3>
  <?php
  $counts = [];
  foreach ($appointments as $a) {
      $svc = null;
      foreach ($services as $s) if ($s['id'] === ($a['service_id'] ?? '')) $svc = $s;
      $name = $svc['title'] ?? 'Outro';
      $counts[$name] = ($counts[$name] ?? 0) + 1;
  }
  arsort($counts);
  $total = array_sum($counts);
  $colors = ['hsl(245 60% 55%)', 'hsl(200 70% 50%)', 'hsl(160 60% 45%)', 'hsl(280 60% 55%)', 'hsl(30 70% 50%)', 'hsl(350 60% 50%)'];
  $i = 0;
  if (empty($counts)): ?>
    <p class="text-sm text-muted">Nenhum agendamento registrado ainda</p>
  <?php else: foreach ($counts as $name => $val):
    $pct = $total > 0 ? ($val / $total) * 100 : 0;
    $c = $colors[$i % count($colors)]; $i++;
  ?>
    <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:0.5rem">
      <div style="width:0.625rem;height:0.625rem;border-radius:50%;background:<?= $c ?>;flex-shrink:0"></div>
      <span class="text-sm" style="flex:1"><?= htmlspecialchars($name) ?></span>
      <span class="text-xs text-muted"><?= $val ?> (<?= round($pct) ?>%)</span>
      <div style="width:6rem;height:0.375rem;border-radius:9999px;background:hsl(0 0% 100% / 0.06);overflow:hidden">
        <div style="height:100%;width:<?= $pct ?>%;border-radius:9999px;background:<?= $c ?>"></div>
      </div>
    </div>
  <?php endforeach; endif; ?>
</div>
