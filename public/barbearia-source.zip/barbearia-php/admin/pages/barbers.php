<?php
$token = getAdminToken();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    if ($action === 'create') {
        supabaseRequest('barbers', 'POST', [
            'name' => $_POST['name'] ?? '', 'specialty' => $_POST['specialty'] ?: null,
            'active' => isset($_POST['active']), 'sort_order' => intval($_POST['sort_order'] ?? 0),
        ], $token);
    } elseif ($action === 'delete' && !empty($_POST['id'])) {
        supabaseRequest('barbers?id=eq.' . urlencode($_POST['id']), 'DELETE', null, $token);
    }
    header('Location: index.php?page=barbers'); exit;
}
$barbers = supabaseRequest('barbers?select=*&order=sort_order.asc', 'GET', null, $token) ?: [];
?>
<div class="flex-between mb-4">
  <h2 class="text-lg font-bold">Barbeiros</h2>
  <button onclick="document.getElementById('barberModal').style.display='flex'" class="btn-primary" style="padding:0.5rem 1rem;font-size:0.75rem">＋ Novo Barbeiro</button>
</div>
<div style="display:flex;flex-direction:column;gap:0.75rem">
  <?php foreach ($barbers as $b): ?>
    <div class="glass-card" style="padding:1rem;display:flex;align-items:center;gap:1rem">
      <div style="width:3rem;height:3rem;border-radius:0.75rem;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.125rem;background:hsl(245 60% 55%/0.12);color:var(--accent-light)"><?= mb_substr($b['name'], 0, 1) ?></div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:0.5rem">
          <h3 class="text-sm font-semibold"><?= htmlspecialchars($b['name']) ?></h3>
          <?php if (!$b['active']): ?><span class="badge badge-cancelled">Inativo</span><?php endif; ?>
        </div>
        <p class="text-xs text-muted"><?= htmlspecialchars($b['specialty'] ?? 'Sem especialidade') ?></p>
      </div>
      <form method="POST" style="display:inline" onsubmit="return confirm('Excluir?')">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $b['id'] ?>">
        <button type="submit" class="btn-danger">🗑️</button>
      </form>
    </div>
  <?php endforeach; ?>
  <?php if (empty($barbers)): ?><div class="glass-card p-5" style="text-align:center"><p class="text-sm text-muted">Nenhum barbeiro cadastrado</p></div><?php endif; ?>
</div>

<div id="barberModal" class="modal-overlay" style="display:none" onclick="if(event.target===this)this.style.display='none'">
  <form method="POST" class="glass-card-strong modal-content" style="padding:1.5rem">
    <div class="flex-between mb-4"><h3 class="font-bold">Novo Barbeiro</h3><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.25rem">✕</button></div>
    <input type="hidden" name="action" value="create">
    <div style="display:flex;flex-direction:column;gap:0.75rem">
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Nome *</label><input name="name" class="glass-input" required></div>
      <div><label class="text-xs font-semibold text-muted uppercase tracking-wider" style="display:block;margin-bottom:0.25rem">Especialidade</label><input name="specialty" class="glass-input"></div>
      <label style="display:flex;align-items:center;gap:0.5rem"><input type="checkbox" name="active" checked style="accent-color:var(--accent)"> <span class="text-sm">Ativo</span></label>
      <input type="hidden" name="sort_order" value="0">
    </div>
    <button type="submit" class="btn-primary w-full" style="margin-top:1rem">Adicionar</button>
  </form>
</div>
