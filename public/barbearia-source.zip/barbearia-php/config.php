<?php
// Configurações do Supabase (Lovable Cloud)
define('SUPABASE_URL', 'https://vikabbqyfduibrykikvx.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZpa2FiYnF5ZmR1aWJyeWtpa3Z4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MzU0NDksImV4cCI6MjA4NjQxMTQ0OX0.fdTHErAIVttA7QI1nl6GcYdBnmB0g8j-X343W-HEFOQ');

session_start();

function supabaseRequest($endpoint, $method = 'GET', $body = null, $token = null) {
    $url = SUPABASE_URL . '/rest/v1/' . $endpoint;
    $headers = [
        'apikey: ' . SUPABASE_ANON_KEY,
        'Content-Type: application/json',
        'Prefer: return=representation',
    ];
    if ($token) $headers[] = 'Authorization: Bearer ' . $token;
    else $headers[] = 'Authorization: Bearer ' . SUPABASE_ANON_KEY;

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    } elseif ($method === 'PATCH') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    } elseif ($method === 'DELETE') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    }
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function supabaseAuth($endpoint, $body) {
    $url = SUPABASE_URL . '/auth/v1/' . $endpoint;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'apikey: ' . SUPABASE_ANON_KEY,
        'Content-Type: application/json',
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function getSettings() {
    $data = supabaseRequest('business_settings?select=*');
    $map = [];
    if (is_array($data)) foreach ($data as $row) $map[$row['key']] = $row['value'] ?? '';
    return $map;
}

function isAdmin() {
    return isset($_SESSION['admin_token']);
}

function getAdminToken() {
    return $_SESSION['admin_token'] ?? null;
}
?>