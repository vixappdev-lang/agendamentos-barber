<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('SUPABASE_URL', 'https://vikabbqyfduibrykikvx.supabase.co');
define('SUPABASE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZpa2FiYnF5ZmR1aWJyeWtpa3Z4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MzU0NDksImV4cCI6MjA4NjQxMTQ0OX0.fdTHErAIVttA7QI1nl6GcYdBnmB0g8j-X343W-HEFOQ');
define('SUPABASE_TIMEOUT', 20);

function build_headers($token = null, array $extra = []) {
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . SUPABASE_KEY,
        'Authorization: Bearer ' . ($token ?: SUPABASE_KEY),
    ];

    return array_merge($headers, $extra);
}

function supabase_http_request($url, $method = 'GET', $data = null, $token = null, array $extraHeaders = []) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, build_headers($token, $extraHeaders));
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_TIMEOUT, SUPABASE_TIMEOUT);

    if ($data !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    }

    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $decoded = null;
    if (is_string($response) && $response !== '') {
        $decoded = json_decode($response, true);
    }

    return [
        'data' => $decoded,
        'status' => $httpCode,
        'error' => $curlError ?: null,
        'raw' => $response,
    ];
}

function supabase_auth($endpoint, array $data) {
    $url = SUPABASE_URL . '/auth/v1/' . ltrim($endpoint, '/');
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'apikey: ' . SUPABASE_KEY,
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_TIMEOUT, SUPABASE_TIMEOUT);
    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response ?: '[]', true);
}

function refresh_admin_session() {
    $refreshToken = $_SESSION['admin_refresh_token'] ?? '';
    if (!$refreshToken) {
        return false;
    }

    $result = supabase_auth('token?grant_type=refresh_token', [
        'refresh_token' => $refreshToken,
    ]);

    if (empty($result['access_token'])) {
        unset($_SESSION['admin_token'], $_SESSION['admin_refresh_token'], $_SESSION['admin_user_id']);
        return false;
    }

    $_SESSION['admin_token'] = $result['access_token'];
    if (!empty($result['refresh_token'])) {
        $_SESSION['admin_refresh_token'] = $result['refresh_token'];
    }
    if (!empty($result['user']['id'])) {
        $_SESSION['admin_user_id'] = $result['user']['id'];
    }

    return true;
}

function supabase_request($endpoint, $method = 'GET', $data = null, $token = null) {
    $url = SUPABASE_URL . '/rest/v1/' . ltrim($endpoint, '/');
    $headers = ['Prefer: return=representation'];
    $result = supabase_http_request($url, $method, $data, $token, $headers);

    if ($result['status'] === 401 && $token && refresh_admin_session()) {
        $result = supabase_http_request($url, $method, $data, $_SESSION['admin_token'], $headers);
    }

    return $result;
}

function is_admin() {
    return !empty($_SESSION['admin_token']) && !empty($_SESSION['admin_user_id']);
}

function require_admin() {
    if (!is_admin()) {
        header('Location: login.php');
        exit;
    }
}

function get_settings() {
    $result = supabase_request('business_settings?select=key,value');
    $settings = [];

    if (!empty($result['data']) && is_array($result['data'])) {
        foreach ($result['data'] as $row) {
            if (!isset($row['key'])) {
                continue;
            }
            $settings[$row['key']] = $row['value'] ?? '';
        }
    }

    return $settings;
}
?>
