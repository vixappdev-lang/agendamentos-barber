# Barbearia - Clone PHP

Clone em PHP/HTML/CSS do projeto de barbearia da Lovable Cloud.

## Requisitos
- PHP 7.4+ com cURL habilitado
- Servidor Apache/Nginx ou PHP built-in server

## Como rodar

```bash
cd barbearia-php
php -S localhost:8000
```

Acesse: http://localhost:8000

## Admin
Acesse: http://localhost:8000/admin/login.php
Use as mesmas credenciais do painel admin da Lovable Cloud.

## Estrutura
```
├── config.php            # Configuração Supabase / funções auxiliares
├── index.php             # Página principal (serviços + loja)
├── agendar.php           # Fluxo de agendamento
├── assets/style.css      # CSS com mesmo design system (glassmorphism, cores, etc)
├── includes/
│   ├── header.php        # Header com logo e navegação
│   └── footer.php        # Footer com info da barbearia
├── admin/
│   ├── login.php         # Login do admin
│   ├── index.php         # Entry point do painel admin
│   ├── layout.php        # Layout com sidebar e header
│   ├── logout.php        # Logout
│   └── pages/
│       ├── dashboard.php     # Dashboard com stats
│       ├── services.php      # CRUD de serviços
│       ├── barbers.php       # CRUD de barbeiros
│       ├── appointments.php  # Listagem de agendamentos
│       ├── coupons.php       # CRUD de cupons
│       ├── settings.php      # Configurações gerais
│       ├── store.php         # Produtos, pedidos, config da loja
│       └── prize-wheel.php   # Config da roleta premiada
```

## Conexão com banco
O projeto se conecta ao **mesmo banco de dados** da Lovable Cloud via API REST do Supabase.
Todos os dados (serviços, barbeiros, agendamentos, cupons, pedidos, configurações) são compartilhados.
