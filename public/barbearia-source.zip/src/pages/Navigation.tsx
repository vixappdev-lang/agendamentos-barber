import { useEffect, useRef, useState, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { X, Plus, Minus, RotateCcw, Eye } from "lucide-react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import TransportModeModal, { type TransportMode, getModeConfig } from "@/components/navigation/TransportModeModal";
import TurnInstruction, { type StepInstruction } from "@/components/navigation/TurnInstruction";

const MAP_STYLE = "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json";

type ViewMode = "3d" | "2d";

// ── 3D Buildings Layer ──
const findBuildingSource = (map: maplibregl.Map): string | null => {
  const style = map.getStyle();
  if (!style?.sources) return null;
  // Try common source names
  for (const name of ["openmaptiles", "carto", "composite", "mapbox"]) {
    if (style.sources[name]) return name;
  }
  // Fallback: first vector source
  for (const [name, src] of Object.entries(style.sources)) {
    if ((src as any).type === "vector") return name;
  }
  return null;
};

const add3DBuildings = (map: maplibregl.Map) => {
  if (map.getLayer("3d-buildings")) return;

  const layers = map.getStyle().layers;
  if (!layers) return;

  let labelLayerId: string | undefined;
  for (const layer of layers) {
    if (layer.type === "symbol" && (layer as any).layout?.["text-field"]) {
      labelLayerId = layer.id;
      break;
    }
  }

  const source = findBuildingSource(map);
  if (!source) return;

  map.addLayer(
    {
      id: "3d-buildings",
      source,
      "source-layer": "building",
      type: "fill-extrusion",
      minzoom: 14,
      paint: {
        "fill-extrusion-color": [
          "interpolate", ["linear"], ["get", "render_height"],
          0, "hsl(230, 22%, 18%)",
          20, "hsl(230, 18%, 24%)",
          50, "hsl(230, 14%, 30%)",
          100, "hsl(225, 12%, 35%)",
          200, "hsl(220, 10%, 40%)",
        ],
        "fill-extrusion-height": [
          "interpolate", ["linear"], ["zoom"],
          14, 0,
          15.5, ["get", "render_height"],
        ],
        "fill-extrusion-base": [
          "interpolate", ["linear"], ["zoom"],
          14, 0,
          15.5, ["get", "render_min_height"],
        ],
        "fill-extrusion-opacity": 0.88,
        "fill-extrusion-vertical-gradient": true,
      },
    },
    labelLayerId
  );
};

const remove3DBuildings = (map: maplibregl.Map) => {
  if (map.getLayer("3d-buildings")) {
    map.removeLayer("3d-buildings");
  }
};

// ── Lerp helper ──
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const lerpAngle = (a: number, b: number, t: number) => {
  let diff = ((b - a + 540) % 360) - 180;
  return a + diff * t;
};

const Navigation = () => {
  const [searchParams] = useSearchParams();
  const destLat = parseFloat(searchParams.get("lat") || "-23.5505");
  const destLng = parseFloat(searchParams.get("lng") || "-46.6333");
  const destAddress = searchParams.get("address") || "Destino";

  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<maplibregl.Map | null>(null);
  const destMarkerRef = useRef<maplibregl.Marker | null>(null);
  const userMarkerRef = useRef<maplibregl.Marker | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const lastBearingRef = useRef(0);
  const lastPositionRef = useRef<{ lat: number; lng: number } | null>(null);
  const lastSpeedRef = useRef(0);
  const routeVersionRef = useRef(0);
  const routeCoordsRef = useRef<[number, number][] | null>(null);
  const stepsRef = useRef<any[] | null>(null);
  const totalDistanceRef = useRef(0);
  const smoothAnimRef = useRef<number | null>(null);
  const targetCameraRef = useRef<{ lat: number; lng: number; bearing: number; zoom: number; pitch: number } | null>(null);
  const currentCameraRef = useRef<{ lat: number; lng: number; bearing: number } | null>(null);
  const offRouteCountRef = useRef(0);
  const userInteractingRef = useRef(false);
  const recenterTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [transportMode, setTransportMode] = useState<TransportMode | null>(null);
  const [osrmProfile, setOsrmProfile] = useState("driving");
  const [routeInfo, setRouteInfo] = useState<{ distance: string; duration: string; eta: string; distanceMeters?: number } | null>(null);
  const [currentStreet, setCurrentStreet] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<StepInstruction | null>(null);
  const [nextStep, setNextStep] = useState<StepInstruction | null>(null);
  const [status, setStatus] = useState<"choosing" | "locating" | "routing" | "active" | "arrived" | "recalculating" | "error">("choosing");
  const [errorMsg, setErrorMsg] = useState("");
  const [mapReady, setMapReady] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>("3d");
  const viewModeRef = useRef<ViewMode>("3d");
  const [progressPercent, setProgressPercent] = useState(0);

  // ── Destination marker ──
  const createDestMarker = useCallback((map: maplibregl.Map) => {
    const el = document.createElement("div");
    el.innerHTML = `
      <div style="position:relative;width:48px;height:62px;">
        <div style="position:absolute;bottom:-4px;left:50%;transform:translateX(-50%);width:22px;height:8px;background:rgba(139,92,246,0.4);border-radius:50%;filter:blur(3px);"></div>
        <svg viewBox="0 0 40 52" width="48" height="62" style="filter:drop-shadow(0 6px 12px rgba(0,0,0,0.5));">
          <defs><linearGradient id="ng" x1="0" y1="0" x2="0.5" y2="1">
            <stop offset="0%" stop-color="#a78bfa"/><stop offset="100%" stop-color="#7c3aed"/>
          </linearGradient></defs>
          <path d="M20 2C10 2 2 10 2 20c0 12 18 30 18 30s18-18 18-30C38 10 30 2 20 2z" fill="url(#ng)" stroke="white" stroke-width="2"/>
          <circle cx="20" cy="18" r="7" fill="white"/><circle cx="20" cy="18" r="3.5" fill="#7c3aed"/>
        </svg>
      </div>`;
    return new maplibregl.Marker({ element: el, anchor: "bottom" }).setLngLat([destLng, destLat]).addTo(map);
  }, [destLat, destLng]);

  // ── User marker (navigation arrow) ──
  const createUserMarker = useCallback((map: maplibregl.Map, lat: number, lng: number) => {
    const el = document.createElement("div");
    el.innerHTML = `
      <div style="position:relative;width:52px;height:52px;" id="nav-arrow-container">
        <div style="position:absolute;inset:0;background:rgba(59,130,246,0.15);border-radius:50%;animation:nav-pulse 2s ease-out infinite;"></div>
        <div style="position:absolute;inset:4px;background:rgba(59,130,246,0.08);border-radius:50%;"></div>
        <svg viewBox="0 0 48 48" width="52" height="52" style="position:absolute;inset:0;filter:drop-shadow(0 3px 10px rgba(59,130,246,0.6));" id="nav-arrow-svg">
          <circle cx="24" cy="24" r="15" fill="#2563eb" stroke="white" stroke-width="3"/>
          <path d="M24 10 L31 29 L24 24 L17 29 Z" fill="white"/>
        </svg>
      </div>
      <style>@keyframes nav-pulse{0%{transform:scale(1);opacity:0.6}100%{transform:scale(2.8);opacity:0}}</style>`;
    return new maplibregl.Marker({ element: el, anchor: "center" }).setLngLat([lng, lat]).addTo(map);
  }, []);

  // ── Rotate user arrow ──
  const rotateArrow = useCallback((bearing: number) => {
    const svg = document.getElementById("nav-arrow-svg");
    if (svg) svg.style.transform = `rotate(${bearing}deg)`;
  }, []);

  // ── Calculate bearing ──
  const calcBearing = useCallback((from: { lat: number; lng: number }, to: { lat: number; lng: number }) => {
    const dLng = ((to.lng - from.lng) * Math.PI) / 180;
    const lat1 = (from.lat * Math.PI) / 180;
    const lat2 = (to.lat * Math.PI) / 180;
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
  }, []);

  // ── Parse OSRM steps into instructions ──
  const parseSteps = useCallback((steps: any[]): StepInstruction[] => {
    return steps.map((s: any) => ({
      maneuver: s.maneuver?.type || "straight",
      modifier: s.maneuver?.modifier,
      name: s.name || "",
      distance: s.distance || 0,
    }));
  }, []);

  // ── Find current step based on user position ──
  const findCurrentStep = useCallback((userLat: number, userLng: number, steps: any[]) => {
    if (!steps || steps.length === 0) return;
    let minDist = Infinity;
    let closestIdx = 0;

    for (let i = 0; i < steps.length; i++) {
      const loc = steps[i].maneuver?.location;
      if (!loc) continue;
      const d = Math.sqrt(Math.pow(userLat - loc[1], 2) + Math.pow(userLng - loc[0], 2));
      if (d < minDist) {
        minDist = d;
        closestIdx = i;
      }
    }

    const threshold = 0.0003;
    if (minDist < threshold && closestIdx < steps.length - 1) {
      closestIdx++;
    }

    const parsed = parseSteps(steps);
    setCurrentStep(parsed[closestIdx] || null);
    setNextStep(parsed[closestIdx + 1] || null);
  }, [parseSteps]);

  // ── Check if user is off-route ──
  const isOffRoute = useCallback((lat: number, lng: number): boolean => {
    const coords = routeCoordsRef.current;
    if (!coords || coords.length < 2) return false;

    // Find min distance from user to any route segment
    let minDist = Infinity;
    for (let i = 0; i < coords.length; i++) {
      const dx = lng - coords[i][0];
      const dy = lat - coords[i][1];
      const d = Math.sqrt(dx * dx + dy * dy) * 111000; // approx meters
      if (d < minDist) minDist = d;
    }

    // Off-route if more than 50m away
    return minDist > 50;
  }, []);

  // ── Fetch route ──
  const fetchRoute = useCallback(async (fromLng: number, fromLat: number, profile: string) => {
    try {
      const res = await fetch(
        `https://router.project-osrm.org/route/v1/${profile}/${fromLng},${fromLat};${destLng},${destLat}?overview=full&geometries=geojson&steps=true`
      );
      const data = await res.json();
      if (data.code !== "Ok" || !data.routes?.[0]) return null;
      const route = data.routes[0];
      const distMeters = route.distance;
      const distKm = distMeters >= 1000 ? (distMeters / 1000).toFixed(1) : `0.${Math.round(distMeters / 100)}`;
      const distLabel = distMeters >= 1000 ? `${distKm} km` : `${Math.round(distMeters)} m`;

      // OSRM returns duration in seconds for the profile used (driving/cycling/foot)
      // Use raw duration directly — it's already profile-accurate
      const durationSec = route.duration;
      const durMin = Math.round(durationSec / 60);
      const durLabel = durMin < 1 ? "< 1 min" : durMin === 1 ? "1 min" : `${durMin} min`;
      
      const now = new Date();
      now.setSeconds(now.getSeconds() + durationSec);
      const eta = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

      let street: string | null = null;
      const steps = route.legs?.[0]?.steps || [];
      if (steps[0]?.name) street = steps[0].name || null;

      stepsRef.current = steps;

      return {
        geometry: route.geometry,
        distance: distLabel,
        duration: durLabel,
        eta,
        street,
        distanceMeters: route.distance,
        steps,
      };
    } catch {
      return null;
    }
  }, [destLat, destLng]);

  // ── Draw route ──
  const drawRoute = useCallback((map: maplibregl.Map, coordinates: [number, number][]) => {
    routeCoordsRef.current = coordinates;
    const geojson: GeoJSON.Feature<GeoJSON.LineString> = {
      type: "Feature",
      properties: {},
      geometry: { type: "LineString", coordinates },
    };

    const src = map.getSource("nav-route") as maplibregl.GeoJSONSource | undefined;
    if (src) {
      src.setData(geojson);
      return;
    }

    map.addSource("nav-route", { type: "geojson", data: geojson });
    map.addLayer({
      id: "nav-route-glow", type: "line", source: "nav-route",
      layout: { "line-join": "round", "line-cap": "round" },
      paint: { "line-color": "#a78bfa", "line-width": 20, "line-opacity": 0.2, "line-blur": 10 },
    });
    map.addLayer({
      id: "nav-route-casing", type: "line", source: "nav-route",
      layout: { "line-join": "round", "line-cap": "round" },
      paint: { "line-color": "#1e1b4b", "line-width": 9, "line-opacity": 0.9 },
    });
    map.addLayer({
      id: "nav-route-line", type: "line", source: "nav-route",
      layout: { "line-join": "round", "line-cap": "round" },
      paint: { "line-color": "#7c3aed", "line-width": 5.5, "line-opacity": 1 },
    });
  }, []);

  // ── Redraw route on style change ──
  const redrawRouteOnStyle = useCallback((map: maplibregl.Map) => {
    if (routeCoordsRef.current) {
      try { map.removeLayer("nav-route-glow"); } catch {}
      try { map.removeLayer("nav-route-casing"); } catch {}
      try { map.removeLayer("nav-route-line"); } catch {}
      try { map.removeSource("nav-route"); } catch {}
      drawRoute(map, routeCoordsRef.current);
    }
  }, [drawRoute]);

  // ── Speed-adaptive camera parameters ──
  const getAdaptiveCamera = useCallback((mode: TransportMode, speedMs: number, currentViewMode: ViewMode) => {
    const config = getModeConfig(mode);
    const speedKmh = speedMs * 3.6;

    if (currentViewMode === "2d") {
      return { zoom: 16, offsetDist: 0.0002, pitch: 0, transitionSpeed: 800 };
    }

    let zoom = config.zoomLevel;
    if (mode === "driving" || mode === "motorcycle") {
      if (speedKmh > 60) zoom = config.zoomLevel - 0.5;
      else if (speedKmh > 40) zoom = config.zoomLevel - 0.3;
      else if (speedKmh < 10) zoom = config.zoomLevel + 0.3;
    }

    let offsetDist = 0.0004;
    if (speedKmh > 60) offsetDist = 0.0008;
    else if (speedKmh > 30) offsetDist = 0.0006;
    else if (speedKmh < 5) offsetDist = 0.0002;

    return { zoom, offsetDist, pitch: config.pitch, transitionSpeed: config.transitionSpeed };
  }, []);

  // ── Smooth camera animation loop ──
  const startSmoothCamera = useCallback(() => {
    if (smoothAnimRef.current) return;

    const animate = () => {
      const map = mapInstance.current;
      const target = targetCameraRef.current;
      if (!map || !target || userInteractingRef.current) {
        smoothAnimRef.current = requestAnimationFrame(animate);
        return;
      }

      if (!currentCameraRef.current) {
        currentCameraRef.current = { lat: target.lat, lng: target.lng, bearing: target.bearing };
      }

      const t = 0.08; // smoothing factor
      const cur = currentCameraRef.current;
      cur.lat = lerp(cur.lat, target.lat, t);
      cur.lng = lerp(cur.lng, target.lng, t);
      cur.bearing = lerpAngle(cur.bearing, target.bearing, t);

      map.jumpTo({
        center: [cur.lng, cur.lat],
        zoom: target.zoom,
        pitch: target.pitch,
        bearing: cur.bearing,
      });

      smoothAnimRef.current = requestAnimationFrame(animate);
    };

    smoothAnimRef.current = requestAnimationFrame(animate);
  }, []);

  const stopSmoothCamera = useCallback(() => {
    if (smoothAnimRef.current) {
      cancelAnimationFrame(smoothAnimRef.current);
      smoothAnimRef.current = null;
    }
  }, []);

  // ── Initialize map ──
  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    const map = new maplibregl.Map({
      container: mapRef.current,
      style: MAP_STYLE,
      center: [destLng, destLat],
      zoom: 16,
      pitch: 65,
      bearing: 0,
      attributionControl: false,
      maxPitch: 85,
    });

    map.on("load", () => {
      add3DBuildings(map);
      destMarkerRef.current = createDestMarker(map);
      mapInstance.current = map;
      setMapReady(true);
    });

    map.on("style.load", () => {
      if (viewModeRef.current === "3d") add3DBuildings(map);
      redrawRouteOnStyle(map);
    });

    // Detect user interaction to pause smooth camera
    const onInteractionStart = () => {
      userInteractingRef.current = true;
      if (recenterTimeoutRef.current) clearTimeout(recenterTimeoutRef.current);
    };
    const onInteractionEnd = () => {
      // Auto-resume smooth camera after 5s of no interaction
      recenterTimeoutRef.current = setTimeout(() => {
        userInteractingRef.current = false;
      }, 5000);
    };

    map.on("dragstart", onInteractionStart);
    map.on("zoomstart", onInteractionStart);
    map.on("pitchstart", onInteractionStart);
    map.on("dragend", onInteractionEnd);
    map.on("zoomend", onInteractionEnd);
    map.on("pitchend", onInteractionEnd);

    return () => {
      stopSmoothCamera();
      if (watchIdRef.current !== null) navigator.geolocation.clearWatch(watchIdRef.current);
      map.remove();
      mapInstance.current = null;
    };
  }, [destLat, destLng, createDestMarker, redrawRouteOnStyle, stopSmoothCamera]);

  // ── Toggle view mode ──
  const toggleViewMode = useCallback(() => {
    const map = mapInstance.current;
    if (!map) return;
    const newMode = viewModeRef.current === "3d" ? "2d" : "3d";
    viewModeRef.current = newMode;
    setViewMode(newMode);

    if (newMode === "3d") {
      add3DBuildings(map);
      map.easeTo({ pitch: 65, duration: 800 });
    } else {
      remove3DBuildings(map);
      map.easeTo({ pitch: 0, duration: 800 });
    }
  }, []);

  // ── Start navigation ──
  const startNavigation = useCallback(async (mode: TransportMode, profile: string) => {
    const map = mapInstance.current;
    if (!map || !navigator.geolocation) {
      setStatus("error");
      setErrorMsg("Geolocalização não disponível");
      return;
    }

    setStatus("locating");
    const isFirstFix = { value: true };

    startSmoothCamera();

    const processPosition = async (pos: GeolocationPosition) => {
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      const heading = pos.coords.heading;
      const speed = pos.coords.speed || 0;
      const currentPos = { lat, lng };

      lastSpeedRef.current = speed;

      // Calculate bearing
      let bearing = lastBearingRef.current;
      if (isFirstFix.value) {
        bearing = calcBearing(currentPos, { lat: destLat, lng: destLng });
      } else if (heading != null && !isNaN(heading) && heading >= 0) {
        bearing = heading;
      } else if (lastPositionRef.current) {
        const dist = Math.sqrt(
          Math.pow(lat - lastPositionRef.current.lat, 2) + Math.pow(lng - lastPositionRef.current.lng, 2)
        );
        if (dist > 0.00003) {
          bearing = calcBearing(lastPositionRef.current, currentPos);
        }
      }
      lastBearingRef.current = bearing;
      lastPositionRef.current = currentPos;

      // Update/create user marker with smooth position
      if (userMarkerRef.current) {
        userMarkerRef.current.setLngLat([lng, lat]);
      } else {
        userMarkerRef.current = createUserMarker(map, lat, lng);
      }
      rotateArrow(bearing);

      // Set active immediately
      if (status !== "arrived") setStatus("active");

      // Adaptive camera → set target for smooth loop
      const cam = getAdaptiveCamera(mode, speed, viewModeRef.current);
      const bearingRad = (bearing * Math.PI) / 180;
      const offsetLat = lat + Math.cos(bearingRad) * cam.offsetDist;
      const offsetLng = lng + Math.sin(bearingRad) * cam.offsetDist;

      if (isFirstFix.value) {
        isFirstFix.value = false;
        // Snap immediately on first fix
        currentCameraRef.current = { lat: offsetLat, lng: offsetLng, bearing };
        targetCameraRef.current = { lat: offsetLat, lng: offsetLng, bearing, zoom: cam.zoom, pitch: cam.pitch };
        map.flyTo({
          center: [offsetLng, offsetLat],
          zoom: cam.zoom,
          pitch: cam.pitch,
          bearing,
          duration: 2500,
          essential: true,
        });
      } else {
        targetCameraRef.current = { lat: offsetLat, lng: offsetLng, bearing, zoom: cam.zoom, pitch: cam.pitch };
      }

      // Check if arrived (within 50m)
      const distToDest = Math.sqrt(Math.pow(lat - destLat, 2) + Math.pow(lng - destLng, 2)) * 111000;
      if (distToDest < 50) {
        setStatus("arrived");
        stopSmoothCamera();
        return;
      }

      // Off-route detection
      if (isOffRoute(lat, lng)) {
        offRouteCountRef.current++;
        if (offRouteCountRef.current >= 3) {
          setStatus("recalculating");
          offRouteCountRef.current = 0;
        }
      } else {
        offRouteCountRef.current = 0;
      }

      // Fetch and draw route
      const version = ++routeVersionRef.current;
      const route = await fetchRoute(lng, lat, profile);
      if (version !== routeVersionRef.current) return;
      if (route) {
        if (totalDistanceRef.current === 0) totalDistanceRef.current = route.distanceMeters;
        // Calculate real progress
        const remaining = route.distanceMeters;
        const total = totalDistanceRef.current;
        const pct = total > 0 ? Math.max(0, Math.min(100, ((total - remaining) / total) * 100)) : 0;
        setProgressPercent(pct);

        setRouteInfo({ distance: route.distance, duration: route.duration, eta: route.eta, distanceMeters: route.distanceMeters });
        setCurrentStreet(route.street);
        if (status === "recalculating") setStatus("active");
        drawRoute(map, route.geometry.coordinates as [number, number][]);
        findCurrentStep(lat, lng, route.steps);
      }
    };

    // Geolocation with fallback
    const geoOptions = { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 };
    const fallbackOptions = { enableHighAccuracy: false, timeout: 10000, maximumAge: 30000 };

    const onError = (err: GeolocationPositionError) => {
      if (err.code === 3) {
        navigator.geolocation.getCurrentPosition(
          (pos) => processPosition(pos),
          (err2) => {
            setStatus("error");
            setErrorMsg(err2.code === 1 ? "Permissão de localização negada" : "Erro ao obter localização");
          },
          fallbackOptions
        );
        return;
      }
      setStatus("error");
      setErrorMsg(err.code === 1 ? "Permissão de localização negada" : "Erro ao obter localização");
    };

    navigator.geolocation.getCurrentPosition(
      (pos) => processPosition(pos),
      onError,
      geoOptions
    );

    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => processPosition(pos),
      () => {},
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 3000 }
    );
  }, [destLat, destLng, fetchRoute, drawRoute, createUserMarker, rotateArrow, calcBearing, getAdaptiveCamera, findCurrentStep, isOffRoute, startSmoothCamera, stopSmoothCamera, viewMode, status]);

  // ── Transport mode selected ──
  const handleTransportSelect = (mode: TransportMode, profile: string) => {
    setTransportMode(mode);
    setOsrmProfile(profile);
    if (mapReady) startNavigation(mode, profile);
  };

  useEffect(() => {
    if (mapReady && transportMode && status === "choosing") {
      startNavigation(transportMode, osrmProfile);
    }
  }, [mapReady, transportMode, osrmProfile, status, startNavigation]);

  const handleRecenter = () => {
    userInteractingRef.current = false;
    if (recenterTimeoutRef.current) clearTimeout(recenterTimeoutRef.current);
    const map = mapInstance.current;
    const pos = lastPositionRef.current;
    if (!map || !pos || !transportMode) return;
    const cam = getAdaptiveCamera(transportMode, lastSpeedRef.current, viewModeRef.current);
    const bearingRad = (lastBearingRef.current * Math.PI) / 180;
    const offsetLat = pos.lat + Math.cos(bearingRad) * cam.offsetDist;
    const offsetLng = pos.lng + Math.sin(bearingRad) * cam.offsetDist;
    currentCameraRef.current = { lat: offsetLat, lng: offsetLng, bearing: lastBearingRef.current };
    targetCameraRef.current = { lat: offsetLat, lng: offsetLng, bearing: lastBearingRef.current, zoom: cam.zoom, pitch: cam.pitch };
    map.flyTo({
      center: [offsetLng, offsetLat],
      zoom: cam.zoom,
      pitch: cam.pitch,
      bearing: lastBearingRef.current,
      duration: 1000,
    });
  };

  const handleZoom = (delta: number) => {
    const map = mapInstance.current;
    if (!map) return;
    map.easeTo({ zoom: map.getZoom() + delta, duration: 300 });
  };

  const handleClose = () => {
    stopSmoothCamera();
    window.close();
    window.location.href = "/";
  };

  const modeLabel: Record<TransportMode, string> = {
    driving: "🚗 Carro",
    motorcycle: "🏍️ Moto",
    cycling: "🚲 Bicicleta",
    walking: "🚶 A pé",
  };

  return (
    <div className="fixed inset-0 w-screen h-[100dvh] overflow-hidden touch-none" style={{ background: "hsl(230 18% 6%)" }}>
      {/* Fullscreen map */}
      <div ref={mapRef} className="absolute inset-0 w-full h-full" />

      <style>{`
        @viewport { width: device-width; height: device-height; }
        html, body, #root { overflow: hidden !important; height: 100dvh !important; }
      `}</style>

      {/* Transport mode selection */}
      <AnimatePresence>
        {!transportMode && <TransportModeModal onSelect={handleTransportSelect} />}
      </AnimatePresence>

      {/* Recalculating banner */}
      <AnimatePresence>
        {status === "recalculating" && (
          <motion.div
            initial={{ y: -40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -40, opacity: 0 }}
            className="absolute top-0 left-0 right-0 z-30 flex items-center justify-center py-3 safe-area-top"
            style={{ background: "hsl(30 90% 50% / 0.9)", backdropFilter: "blur(8px)" }}
          >
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
            <span className="text-sm font-bold text-white">Recalculando rota...</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top bar - turn instructions + street */}
      <AnimatePresence>
        {(status === "active" || status === "recalculating") && (
          <motion.div
            initial={{ y: -80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -80, opacity: 0 }}
            className="absolute top-0 left-0 right-0 z-20 safe-area-top"
          >
            <div className="mx-3 mt-3 space-y-2" style={{ marginTop: status === "recalculating" ? "48px" : undefined }}>
              {/* Turn instruction */}
              <TurnInstruction step={currentStep} nextStep={nextStep} />

              {/* Street + mode indicator */}
              <div
                className="px-4 py-2.5 rounded-2xl flex items-center gap-3"
                style={{
                  background: "hsl(0 0% 0% / 0.65)",
                  backdropFilter: "blur(16px)",
                  border: "1px solid hsl(0 0% 100% / 0.06)",
                }}
              >
                <div className="w-2 h-2 rounded-full shrink-0" style={{ background: "#7c3aed", boxShadow: "0 0 8px #7c3aed" }} />
                <div className="flex-1 min-w-0">
                  {currentStreet && (
                    <p className="text-sm font-bold text-foreground truncate">{currentStreet}</p>
                  )}
                  <p className="text-[10px] text-muted-foreground">
                    {transportMode && modeLabel[transportMode]} · Navegando
                  </p>
                </div>
                <button
                  onClick={handleClose}
                  className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: "hsl(0 0% 100% / 0.08)" }}
                >
                  <X className="w-4 h-4 text-foreground/70" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom info panel */}
      <AnimatePresence>
        {(status === "active" || status === "recalculating") && routeInfo && (
          <motion.div
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            className="absolute bottom-0 left-0 right-0 z-20 safe-area-bottom"
          >
            <div
              className="mx-3 mb-3 px-5 py-4 rounded-2xl"
              style={{
                background: "hsl(0 0% 0% / 0.75)",
                backdropFilter: "blur(16px)",
                border: "1px solid hsl(0 0% 100% / 0.08)",
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-foreground">{routeInfo.duration}</span>
                  <span className="text-sm text-muted-foreground">{routeInfo.distance}</span>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Chegada</p>
                  <p className="text-lg font-bold" style={{ color: "hsl(245 60% 70%)" }}>{routeInfo.eta}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: "hsl(0 0% 100% / 0.1)" }}>
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: "linear-gradient(90deg, #7c3aed, #a78bfa)" }}
                    animate={{ width: `${Math.max(2, progressPercent)}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                  />
                </div>
                <p className="text-[10px] text-muted-foreground truncate max-w-[120px]">{destAddress}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Right controls */}
      {transportMode && (
        <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-2">
          {[
            { icon: <Plus className="w-4 h-4" />, action: () => handleZoom(1) },
            { icon: <Minus className="w-4 h-4" />, action: () => handleZoom(-1) },
            { icon: <RotateCcw className="w-4 h-4" />, action: handleRecenter },
            {
              icon: <Eye className="w-4 h-4" />,
              action: toggleViewMode,
              label: viewMode === "3d" ? "2D" : "3D",
            },
          ].map((btn, i) => (
            <button
              key={i}
              onClick={btn.action}
              className="relative w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-90"
              style={{
                background: "hsl(0 0% 0% / 0.55)",
                backdropFilter: "blur(12px)",
                border: "1px solid hsl(0 0% 100% / 0.08)",
              }}
            >
              <span className="text-foreground/80">{btn.icon}</span>
              {"label" in btn && btn.label && (
                <span className="absolute -left-1 -bottom-1 text-[8px] font-bold px-1 rounded" style={{ background: "hsl(245 60% 55%)", color: "white" }}>
                  {btn.label}
                </span>
              )}
            </button>
          ))}
        </div>
      )}

      {/* Loading / Error states */}
      <AnimatePresence>
        {(status === "locating" || status === "routing") && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-30 flex items-center justify-center"
            style={{ background: "hsl(230 20% 5% / 0.6)" }}
          >
            <div className="flex flex-col items-center gap-3 px-6 py-5 rounded-2xl" style={{ background: "hsl(0 0% 0% / 0.7)", backdropFilter: "blur(12px)" }}>
              <div className="w-8 h-8 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "hsl(245 60% 60%)", borderTopColor: "transparent" }} />
              <p className="text-sm font-medium text-foreground/80">
                {status === "locating" ? "Localizando..." : "Calculando rota..."}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {status === "error" && (
        <div className="absolute inset-0 z-30 flex items-center justify-center" style={{ background: "hsl(230 20% 5% / 0.8)" }}>
          <div className="flex flex-col items-center gap-4 px-8 py-6 rounded-2xl max-w-xs text-center" style={{ background: "hsl(0 0% 0% / 0.7)" }}>
            <span className="text-4xl">📍</span>
            <p className="text-sm text-foreground/80">{errorMsg || "Erro na navegação"}</p>
            <button
              onClick={handleClose}
              className="px-6 py-2.5 rounded-xl text-sm font-semibold"
              style={{ background: "hsl(245 60% 55%)", color: "white" }}
            >
              Voltar
            </button>
          </div>
        </div>
      )}

      {/* Arrived */}
      {status === "arrived" && (
        <div className="absolute inset-0 z-30 flex items-center justify-center" style={{ background: "hsl(230 20% 5% / 0.8)" }}>
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex flex-col items-center gap-4 px-8 py-8 rounded-2xl max-w-xs text-center"
            style={{ background: "hsl(0 0% 0% / 0.7)", backdropFilter: "blur(16px)" }}
          >
            <span className="text-5xl">🎉</span>
            <h2 className="text-xl font-bold text-foreground">Você chegou!</h2>
            <p className="text-sm text-muted-foreground">{destAddress}</p>
            <button
              onClick={handleClose}
              className="w-full px-6 py-3 rounded-xl text-sm font-semibold"
              style={{ background: "hsl(245 60% 55%)", color: "white" }}
            >
              Fechar navegação
            </button>
          </motion.div>
        </div>
      )}

      <style>{`
        .safe-area-top { padding-top: env(safe-area-inset-top, 0px); }
        .safe-area-bottom { padding-bottom: env(safe-area-inset-bottom, 0px); }
      `}</style>
    </div>
  );
};

export default Navigation;
